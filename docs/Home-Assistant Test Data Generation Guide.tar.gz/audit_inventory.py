#!/usr/bin/env python3
"""
Audit a single YAML inventory dataset across all available tiers.

Runs well-defined static analysis checks against inventory YAML files and produces
a structured markdown report with FAIL/WARN/INFO findings plus reasoning.

Usage:
    python3 audit_inventory.py <inventories_dir> [--output <dir>] [--tiers tier1 tier2 ...]

    <inventories_dir>   Path containing tier subdirectories (enormous/, large/, etc.)
                        with *.yaml files.
    --output            Where to write the report (default: current directory).
    --tiers             Tiers to check (default: all found).

Output:
    audit-inventory.md  — Structured report with FAIL/WARN/INFO findings.

Severity levels:
    FAIL    Hard requirement violated. Blocks usage.
    WARN    Fuzzy target missed or quality concern. Worth investigating.
    INFO    Observation or potential issue. Be aware.
"""

import argparse
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

import yaml

TIER_ORDER = ["enormous", "large", "medium", "small"]

# ── Guide targets (from generation-principles.md §8, §10) ──

ENORMOUS_ENTITY_TARGETS = {
    "light": (105, 145, "~120 ±15"),
    "binary_sensor": (70, 100, "~80 ±10"),
    "sensor": (70, 100, "~80 ±10"),
    "switch": (50, 70, "~60 ±10"),
    "cover": (15, 25, "~20 ±5"),
    "media_player": (12, 18, "~15 ±3"),
    "fan": (12, 18, "~15 ±3"),
    "lock": (8, 12, "~10 ±2"),
    "climate": (6, 10, "~8 ±2"),
    "vacuum": (3, 3, "3 exact"),
    "lawn_mower": (3, 3, "3 exact"),
    "weather": (3, 3, "3 exact"),
    "todo": (3, 3, "3 exact"),
    "valve": (2, 4, "~3"),
}

TIER_AREA_TARGETS = {
    "enormous": 20,
    "large": 14,
    "medium": 8,
    "small": 5,
}

TIER_ENTITY_RANGES = {
    "enormous": (400, 600),
    "large": (160, 210),
    "medium": (75, 100),
    "small": (34, 42),
}

TIER_DOMAIN_TARGETS = {
    "enormous": 14,
    "large": 14,
    "medium": 13,
    "small": 11,
}

LIGHT_CAPABILITY_TARGETS = {
    "onoff": (0.10, 0.20, "~15-17%"),
    "brightness": (0.20, 0.30, "~25%"),
    "color_temp": (0.30, 0.40, "~35%"),
    "hs": (0.15, 0.25, "~20% RGB"),
    "rgbw": (0.03, 0.08, "~5% RGBW"),
}

MIN_SENSOR_DEVICE_CLASSES = 10
MIN_BINARY_SENSOR_DEVICE_CLASSES = 10


# ── Loading ──

def load_inventory(tier_dir: Path) -> dict:
    """Load a tier's full inventory."""
    result = {
        "areas": [],
        "area_ids": set(),
        "area_names": set(),
        "entities": [],
        "entity_ids": set(),
        "entity_names": set(),
        "entities_by_domain": defaultdict(list),
        "domains": set(),
    }

    areas_path = tier_dir / "areas.yaml"
    if areas_path.exists():
        with open(areas_path) as f:
            data = yaml.safe_load(f)
        if data and "areas" in data:
            for a in data["areas"]:
                result["areas"].append(a)
                result["area_ids"].add(a.get("id", ""))
                result["area_names"].add(a.get("name", ""))

    for yaml_file in sorted(tier_dir.glob("*.yaml")):
        if yaml_file.name == "areas.yaml":
            continue
        domain = yaml_file.stem
        with open(yaml_file) as f:
            data = yaml.safe_load(f)
        if data and "entities" in data:
            for e in data["entities"]:
                e["_source_file"] = yaml_file.name
                e["_domain"] = domain
                result["entities"].append(e)
                eid = e.get("entity_id", "")
                name = e.get("name", "")
                if eid:
                    result["entity_ids"].add(eid)
                if name:
                    result["entity_names"].add(name)
                result["entities_by_domain"][domain].append(e)
                result["domains"].add(domain)

    return result


# ── Checks ──

def check_entity_counts(inv: dict, tier_name: str) -> list:
    """Check entity counts against targets."""
    findings = []
    total = len(inv["entities"])

    # Total entity range
    if tier_name in TIER_ENTITY_RANGES:
        lo, hi = TIER_ENTITY_RANGES[tier_name]
        if total < lo:
            findings.append(("FAIL", f"Total entity count {total} below target range "
                            f"({lo}-{hi}) for {tier_name} tier.",
                            f"Undershoot by {lo - total}. Check if domains are "
                            f"missing entities or entire domain YAML files are absent."))
        elif total > hi:
            findings.append(("WARN", f"Total entity count {total} above target range "
                            f"({lo}-{hi}) for {tier_name} tier.",
                            f"Overshoot by {total - hi}. May indicate padding that "
                            f"doesn't improve test coverage."))
        else:
            findings.append(("INFO", f"Total entity count {total} within target range "
                            f"({lo}-{hi}) for {tier_name} tier.", ""))

    # Per-domain counts (enormous only — smaller tiers don't have per-domain targets)
    if tier_name == "enormous":
        for domain, (lo, hi, label) in ENORMOUS_ENTITY_TARGETS.items():
            actual = len(inv["entities_by_domain"].get(domain, []))
            if actual < lo:
                findings.append(("WARN",
                    f"{domain}: {actual} entities, below target {label} "
                    f"(range {lo}-{hi}).",
                    f"Undershoot by {lo - actual}. May reduce state coverage "
                    f"or disambiguation surface."))
            elif actual > hi:
                findings.append(("WARN",
                    f"{domain}: {actual} entities, above target {label} "
                    f"(range {lo}-{hi}).",
                    f"Overshoot by {actual - hi}. Check if inflation is "
                    f"justified for state coverage."))

    return findings


def check_area_counts(inv: dict, tier_name: str) -> list:
    """Check area counts against targets."""
    findings = []
    actual = len(inv["areas"])
    target = TIER_AREA_TARGETS.get(tier_name)

    if target:
        if actual != target:
            findings.append(("WARN",
                f"Area count {actual} != target {target} for {tier_name} tier.",
                f"Delta: {actual - target:+d}."))
        else:
            findings.append(("INFO",
                f"Area count {actual} matches target {target} for {tier_name} tier.",
                ""))

    return findings


def check_domain_count(inv: dict, tier_name: str) -> list:
    """Check number of distinct domains."""
    findings = []
    actual = len(inv["domains"])
    target = TIER_DOMAIN_TARGETS.get(tier_name)

    if target:
        if actual < target:
            findings.append(("WARN",
                f"Domain count {actual} < target {target} for {tier_name} tier.",
                f"Missing domains reduce tool coverage surface."))
        elif actual > target:
            findings.append(("INFO",
                f"Domain count {actual} > target {target} for {tier_name} tier.",
                ""))

    return findings


def check_duplicate_entity_ids(inv: dict) -> list:
    """Check for duplicate entity_ids."""
    findings = []
    id_counts = Counter(e.get("entity_id", "") for e in inv["entities"])
    dupes = {eid: count for eid, count in id_counts.items() if count > 1 and eid}

    if dupes:
        for eid, count in sorted(dupes.items()):
            findings.append(("FAIL",
                f"Duplicate entity_id: '{eid}' appears {count} times.",
                f"Entity IDs must be unique. Check for copy-paste errors."))
    else:
        findings.append(("INFO", "No duplicate entity_ids found.", ""))

    return findings


def check_area_references(inv: dict) -> list:
    """Check that entity area references exist in areas.yaml."""
    findings = []
    missing = []

    for e in inv["entities"]:
        area = e.get("area")
        if area and area not in inv["area_ids"]:
            missing.append((e.get("entity_id", "?"), area))

    if missing:
        for eid, area in missing:
            findings.append(("FAIL",
                f"{eid}: references area '{area}' not found in areas.yaml.",
                "Entity references a nonexistent area. Fix areas.yaml or "
                "the entity's area field."))
    else:
        findings.append(("INFO", "All entity area references are valid.", ""))

    return findings


def check_meta_states(inv: dict, tier_name: str) -> list:
    """Check for unavailable/unknown meta-state entities."""
    findings = []

    unavailable = [e for e in inv["entities"]
                   if e.get("state") == "unavailable"]
    unknown = [e for e in inv["entities"]
               if e.get("state") == "unknown"]

    # Check for actionable unavailable (light, switch, cover, lock, fan, etc.)
    actionable_domains = {"light", "switch", "cover", "lock", "fan", "climate",
                         "media_player", "vacuum", "lawn_mower", "valve"}
    actionable_unavailable = [e for e in unavailable
                              if e.get("_domain") in actionable_domains]

    if tier_name == "enormous":
        if not unavailable:
            findings.append(("FAIL",
                "No entities with state 'unavailable'.",
                "Guide §9 requires at least one unavailable entity. "
                "Needed for edge case test generation (Step 8d)."))
        elif not actionable_unavailable:
            findings.append(("FAIL",
                f"{len(unavailable)} unavailable entities found, but none "
                f"are in actionable domains ({', '.join(sorted(actionable_domains))}).",
                "Guide §9 requires at least one unavailable entity in an "
                "actionable domain (not just sensors). Needed for 'attempt "
                "action on offline device' test cases."))
        else:
            eids = [e.get("entity_id") for e in actionable_unavailable]
            findings.append(("INFO",
                f"Actionable unavailable entities: {', '.join(eids)}.", ""))

        if not unknown:
            findings.append(("WARN",
                "No entities with state 'unknown'.",
                "Consider adding at least one 'unknown' state entity for "
                "edge case coverage."))
    else:
        # Smaller tiers: just report, don't FAIL
        if actionable_unavailable:
            eids = [e.get("entity_id") for e in actionable_unavailable]
            findings.append(("INFO",
                f"Actionable unavailable entities present: {', '.join(eids)}.",
                ""))
        else:
            findings.append(("WARN",
                f"No actionable unavailable entities in {tier_name} tier.",
                "If the enormous tier had one, verify it survived derivation."))

    return findings


def check_null_area_entities(inv: dict) -> list:
    """Report entities with null/missing area."""
    findings = []

    null_area = [e for e in inv["entities"]
                 if not e.get("area")]

    if null_area:
        by_domain = defaultdict(list)
        for e in null_area:
            by_domain[e.get("_domain", "?")].append(e.get("entity_id", "?"))

        summary_parts = []
        for domain in sorted(by_domain.keys()):
            eids = by_domain[domain]
            summary_parts.append(f"{domain}: {len(eids)}")

        findings.append(("INFO",
            f"{len(null_area)} entities have null/missing area "
            f"({', '.join(summary_parts)}).",
            "Null-area entities are expected for disambiguation testing "
            "(portable devices, speaker groups, etc.). Verify these are "
            "intentional, not missing data."))
    else:
        findings.append(("INFO", "All entities have area assignments.", ""))

    return findings


def check_duplicate_friendly_names(inv: dict) -> list:
    """Find entities sharing the same friendly name."""
    findings = []

    name_counts = defaultdict(list)
    for e in inv["entities"]:
        name = e.get("name", "")
        if name:
            name_counts[name].append(e)

    dupe_groups = {name: ents for name, ents in name_counts.items()
                   if len(ents) > 1}

    if dupe_groups:
        for name, ents in sorted(dupe_groups.items()):
            areas = [e.get("area", "null") for e in ents]
            domains = [e.get("_domain", "?") for e in ents]
            findings.append(("INFO",
                f"Duplicate friendly name '{name}' × {len(ents)}: "
                f"areas=[{', '.join(str(a) for a in areas)}], "
                f"domains=[{', '.join(domains)}].",
                "Duplicate names create disambiguation test surface. "
                "Verify each group has a corresponding test case."))
    else:
        findings.append(("WARN",
            "No duplicate friendly names found.",
            "Disambiguation testing requires at least some duplicate names "
            "across areas. Guide §5 expects these."))

    return findings


def check_light_capability_distribution(inv: dict, tier_name: str) -> list:
    """Check light capability distribution against targets."""
    findings = []

    lights = inv["entities_by_domain"].get("light", [])
    if not lights:
        return findings

    total = len(lights)
    cap_counts = Counter()

    for e in lights:
        attrs = e.get("attributes", {})
        modes = attrs.get("supported_color_modes", [])
        if not modes or modes == ["onoff"]:
            cap_counts["onoff"] += 1
        elif "rgbw" in modes or "rgbww" in modes:
            cap_counts["rgbw"] += 1
        elif "hs" in modes or "rgb" in modes or "xy" in modes:
            cap_counts["hs"] += 1
        elif "color_temp" in modes:
            cap_counts["color_temp"] += 1
        elif "brightness" in modes:
            cap_counts["brightness"] += 1
        else:
            cap_counts["other"] += 1

    if tier_name == "enormous":
        for cap, (lo_pct, hi_pct, label) in LIGHT_CAPABILITY_TARGETS.items():
            actual_count = cap_counts.get(cap, 0)
            actual_pct = actual_count / total if total > 0 else 0
            if actual_pct < lo_pct or actual_pct > hi_pct:
                findings.append(("WARN",
                    f"Light capability '{cap}': {actual_count}/{total} "
                    f"({actual_pct:.1%}) outside target {label} "
                    f"({lo_pct:.0%}-{hi_pct:.0%}).",
                    f"Guide §8 targets this distribution for realistic "
                    f"capability coverage. Delta: "
                    f"{actual_pct - (lo_pct + hi_pct)/2:+.1%} from midpoint."))
            else:
                findings.append(("INFO",
                    f"Light capability '{cap}': {actual_count}/{total} "
                    f"({actual_pct:.1%}) within target {label}.", ""))

    # Always report distribution
    dist_parts = []
    for cap in ["onoff", "brightness", "color_temp", "hs", "rgbw", "other"]:
        count = cap_counts.get(cap, 0)
        if count > 0:
            dist_parts.append(f"{cap}={count} ({count/total:.0%})")
    findings.append(("INFO",
        f"Light capability distribution: {', '.join(dist_parts)}.", ""))

    return findings


def check_device_class_breadth(inv: dict, tier_name: str) -> list:
    """Check device_class variety for sensor and binary_sensor."""
    findings = []

    for domain, min_classes in [("sensor", MIN_SENSOR_DEVICE_CLASSES),
                                 ("binary_sensor", MIN_BINARY_SENSOR_DEVICE_CLASSES)]:
        entities = inv["entities_by_domain"].get(domain, [])
        if not entities:
            continue

        classes = set()
        for e in entities:
            dc = e.get("attributes", {}).get("device_class")
            if dc:
                classes.add(dc)

        actual = len(classes)
        if tier_name == "enormous" and actual < min_classes:
            findings.append(("WARN",
                f"{domain}: {actual} distinct device_classes, "
                f"below minimum {min_classes}.",
                f"Guide §7 targets {min_classes}+ for breadth coverage. "
                f"Classes found: {', '.join(sorted(classes))}"))
        else:
            findings.append(("INFO",
                f"{domain}: {actual} distinct device_classes "
                f"({', '.join(sorted(classes))}).", ""))

    return findings


def check_area_density(inv: dict) -> list:
    """Check entity density per area for skew."""
    findings = []

    area_counts = Counter()
    for e in inv["entities"]:
        area = e.get("area")
        if area:
            area_counts[area] += 1

    if not area_counts:
        return findings

    counts = list(area_counts.values())
    avg = sum(counts) / len(counts)
    max_area = area_counts.most_common(1)[0]
    min_area = area_counts.most_common()[-1]

    # Flag extreme skew: any area >3x average or <0.25x average
    for area, count in area_counts.most_common():
        if count > avg * 3:
            findings.append(("WARN",
                f"Area '{area}' has {count} entities ({count/avg:.1f}x average "
                f"of {avg:.0f}).",
                "High concentration may indicate unrealistic density or "
                "insufficient distribution. Some skew is expected for "
                "'tech hub' areas."))
        elif count < max(2, avg * 0.15):
            findings.append(("WARN",
                f"Area '{area}' has only {count} entities "
                f"(average is {avg:.0f}).",
                "Very sparse areas offer limited testing value. "
                "Consider if this area should exist at this tier."))

    findings.append(("INFO",
        f"Area density range: {min_area[1]} ({min_area[0]}) to "
        f"{max_area[1]} ({max_area[0]}), average {avg:.1f}.", ""))

    return findings


def check_moved_but_not_renamed(inv: dict) -> list:
    """Detect potential moved-but-not-renamed entities using word overlap heuristic."""
    findings = []
    candidates = []

    # Build area id → name mapping
    area_id_to_name = {}
    for a in inv["areas"]:
        area_id_to_name[a.get("id", "")] = a.get("name", "")

    for e in inv["entities"]:
        area_id = e.get("area")
        if not area_id:
            continue

        eid = e.get("entity_id", "")
        name = e.get("name", "")

        # Extract area words from entity_id (remove domain prefix and entity-specific suffix)
        # e.g., light.old_living_room_lamp → ["old", "living", "room", "lamp"]
        if "." in eid:
            eid_parts = eid.split(".", 1)[1].split("_")
        else:
            eid_parts = eid.split("_")

        # Area words from assigned area
        area_words = set(area_id.lower().split("_"))

        # Common area names that might appear in entity_ids
        all_area_words = {}
        for aid in inv["area_ids"]:
            for word in aid.lower().split("_"):
                if word not in ("the", "a", "an"):
                    all_area_words.setdefault(word, set()).add(aid)

        # Check if entity_id contains words from a DIFFERENT area
        eid_words = set(w.lower() for w in eid_parts)

        for word in eid_words:
            if word in all_area_words:
                matching_areas = all_area_words[word]
                # If entity_id contains a word belonging to other area(s)
                # but NOT the assigned area...
                if area_id not in matching_areas and not (area_words & eid_words):
                    # Zero word overlap between entity name area hints and actual area
                    other_areas = matching_areas - {area_id}
                    if other_areas:
                        candidates.append({
                            "entity_id": eid,
                            "name": name,
                            "assigned_area": area_id,
                            "name_suggests": list(other_areas),
                        })
                        break

    if candidates:
        for c in candidates:
            findings.append(("INFO",
                f"Potential moved-but-not-renamed: {c['entity_id']} "
                f"(name: '{c['name']}', area: '{c['assigned_area']}', "
                f"name suggests: {c['name_suggests']}).",
                "Entity name contains words from a different area than "
                "its assignment. This is valuable for testing if intentional. "
                "Verify with LLM analysis."))
    else:
        findings.append(("INFO",
            "No moved-but-not-renamed candidates detected by word heuristic.",
            "This heuristic has limited sensitivity — LLM analysis may catch "
            "additional cases."))

    return findings


def check_companion_groups(inv: dict) -> list:
    """Detect companion entity groups (multi-domain device representations)."""
    findings = []

    # Look for entity_id stems that appear across multiple domains
    # e.g., "aquarium" in light.aquarium_light, sensor.aquarium_temperature, etc.
    stem_to_entities = defaultdict(list)

    # Use significant words from entity_id (skip very common words)
    common_words = {"the", "a", "an", "in", "on", "off", "is", "and", "or",
                    "sensor", "binary_sensor", "switch", "light", "cover",
                    "lock", "climate", "fan", "media_player", "vacuum",
                    "lawn_mower", "weather", "todo", "valve"}

    # Build area-word exclusion set from areas.yaml — these are area name
    # fragments that pollute companion detection by grouping everything in
    # an area together (e.g., "kitchen" matches all kitchen entities).
    area_words = set()
    for area_id in inv["area_ids"]:
        for word in area_id.lower().split("_"):
            if len(word) > 2:
                area_words.add(word)

    exclude_words = common_words | area_words

    for e in inv["entities"]:
        eid = e.get("entity_id", "")
        if "." in eid:
            stem = eid.split(".", 1)[1]
        else:
            stem = eid

        words = set(stem.lower().split("_")) - exclude_words
        for word in words:
            if len(word) > 3:  # Skip short words
                stem_to_entities[word].append(e)

    # Find words that appear in entities across 2+ domains
    groups = {}
    for word, entities in stem_to_entities.items():
        domains = set(e.get("_domain") for e in entities)
        if len(domains) >= 2 and len(entities) >= 2:
            # Deduplicate by entity_id
            seen = set()
            unique_ents = []
            for e in entities:
                eid = e.get("entity_id")
                if eid not in seen:
                    seen.add(eid)
                    unique_ents.append(e)
            if len(set(e.get("_domain") for e in unique_ents)) >= 2:
                key = tuple(sorted(e.get("entity_id") for e in unique_ents))
                if key not in groups:
                    groups[key] = {
                        "keyword": word,
                        "entities": unique_ents,
                        "domains": set(e.get("_domain") for e in unique_ents),
                    }

    # Sort by entity count ascending — smaller groups are more likely to be
    # specific devices; cap output at 20 groups to keep report readable.
    MAX_GROUPS_SHOWN = 20

    if groups:
        sorted_groups = sorted(groups.items(),
                               key=lambda x: len(x[1]["entities"]))
        findings.append(("INFO",
            f"Detected {len(groups)} potential companion entity groups"
            f"{f' (showing {MAX_GROUPS_SHOWN})' if len(groups) > MAX_GROUPS_SHOWN else ''}.",
            f"Area-derived words excluded from grouping: "
            f"{', '.join(sorted(area_words))}."))
        for key, group in sorted_groups[:MAX_GROUPS_SHOWN]:
            eids = [e.get("entity_id") for e in group["entities"]]
            findings.append(("INFO",
                f"  Group '{group['keyword']}': {len(eids)} entities across "
                f"{', '.join(sorted(group['domains']))}.",
                f"  Entities: {', '.join(eids[:8])}"
                f"{'...' if len(eids) > 8 else ''}"))
    else:
        findings.append(("WARN",
            "No companion entity groups detected.",
            "Guide §5 expects 3-5 companion groups in larger inventories."))

    return findings


# ── Subset verification ──

def check_subset_chain(all_inventories: dict) -> list:
    """Verify entity_id subset chain across tiers."""
    findings = []

    pairs = [("small", "medium"), ("medium", "large"), ("large", "enormous")]
    for child_name, parent_name in pairs:
        child = all_inventories.get(child_name)
        parent = all_inventories.get(parent_name)

        if not child or not parent:
            continue

        child_ids = child["entity_ids"]
        parent_ids = parent["entity_ids"]

        orphans = child_ids - parent_ids

        if orphans:
            findings.append(("FAIL",
                f"Subset violation: {len(orphans)} entity_ids in "
                f"{child_name} not found in {parent_name}.",
                f"Orphans: {', '.join(sorted(list(orphans)[:10]))}"
                f"{'...' if len(orphans) > 10 else ''}. "
                f"Derivation should produce strict subsets."))
        else:
            findings.append(("INFO",
                f"Subset verified: {child_name} ({len(child_ids)}) ⊂ "
                f"{parent_name} ({len(parent_ids)}).", ""))

    # Also check area subset
    for child_name, parent_name in pairs:
        child = all_inventories.get(child_name)
        parent = all_inventories.get(parent_name)
        if not child or not parent:
            continue

        child_areas = child["area_ids"]
        parent_areas = parent["area_ids"]
        orphan_areas = child_areas - parent_areas

        if orphan_areas:
            findings.append(("FAIL",
                f"Area subset violation: {len(orphan_areas)} areas in "
                f"{child_name} not found in {parent_name}.",
                f"Orphan areas: {', '.join(sorted(orphan_areas))}"))

    return findings


def check_entity_identity_preservation(all_inventories: dict) -> list:
    """Check that shared entities have identical fields across tiers."""
    findings = []
    mismatches = 0

    # Build entity lookup by entity_id per tier
    tier_entity_map = {}
    for tier_name, inv in all_inventories.items():
        tier_entity_map[tier_name] = {}
        for e in inv["entities"]:
            eid = e.get("entity_id", "")
            if eid:
                tier_entity_map[tier_name][eid] = e

    # Compare shared entities
    tiers_present = [t for t in TIER_ORDER if t in tier_entity_map]
    checked_fields = ["name", "domain", "state"]

    for i, tier_a in enumerate(tiers_present):
        for tier_b in tiers_present[i+1:]:
            shared = (set(tier_entity_map[tier_a].keys()) &
                      set(tier_entity_map[tier_b].keys()))
            for eid in shared:
                e_a = tier_entity_map[tier_a][eid]
                e_b = tier_entity_map[tier_b][eid]
                for field in checked_fields:
                    val_a = e_a.get(field)
                    val_b = e_b.get(field)
                    if val_a != val_b:
                        mismatches += 1
                        if mismatches <= 10:
                            findings.append(("FAIL",
                                f"{eid}: '{field}' differs between "
                                f"{tier_a} ('{val_a}') and "
                                f"{tier_b} ('{val_b}').",
                                "Shared entities must have identical fields "
                                "across tiers (except area for re-area'd entities)."))

    if mismatches > 10:
        findings.append(("FAIL",
            f"... and {mismatches - 10} more field mismatches.",
            "Only first 10 shown."))
    elif mismatches == 0:
        findings.append(("INFO",
            "All shared entities have identical core fields across tiers.", ""))

    return findings


# ── Report generation ──

def format_report(all_findings: dict, all_inventories: dict) -> list:
    """Format findings into markdown report."""
    lines = []
    lines.append("# Inventory Audit Report")
    lines.append("")
    lines.append(f"**Generated:** {__import__('datetime').date.today()}")
    lines.append("")

    # Summary counts
    total_fail = sum(1 for findings in all_findings.values()
                     for sev, _, _ in findings if sev == "FAIL")
    total_warn = sum(1 for findings in all_findings.values()
                     for sev, _, _ in findings if sev == "WARN")
    total_info = sum(1 for findings in all_findings.values()
                     for sev, _, _ in findings if sev == "INFO")

    lines.append(f"**Summary:** {total_fail} FAIL, {total_warn} WARN, "
                 f"{total_info} INFO")
    lines.append("")

    if total_fail > 0:
        lines.append("❌ **Audit has FAIL findings — review required.**")
    elif total_warn > 0:
        lines.append("⚠️ **Audit has WARN findings — review recommended.**")
    else:
        lines.append("✅ **All checks passed.**")
    lines.append("")

    # Tier overview table
    lines.append("## Tier Overview")
    lines.append("")
    lines.append("| Tier | Areas | Entities | Domains |")
    lines.append("|------|-------|----------|---------|")
    for tier_name in TIER_ORDER:
        inv = all_inventories.get(tier_name)
        if inv:
            lines.append(f"| {tier_name} | {len(inv['areas'])} | "
                         f"{len(inv['entities'])} | {len(inv['domains'])} |")
    lines.append("")

    # Per-section findings
    for section_name, findings in all_findings.items():
        if not findings:
            continue

        lines.append(f"## {section_name}")
        lines.append("")

        for severity, message, reasoning in findings:
            icon = {"FAIL": "❌", "WARN": "⚠️", "INFO": "ℹ️"}.get(severity, "")
            lines.append(f"**{severity}** {icon} {message}")
            if reasoning:
                lines.append(f"  → {reasoning}")
            lines.append("")

    return lines


# ── Main ──

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Audit YAML inventory dataset across tiers.")
    parser.add_argument("inventories_dir", type=Path,
                        help="Directory containing tier subdirs with YAML files")
    parser.add_argument("--output", type=Path, default=Path("."),
                        help="Output directory for report")
    parser.add_argument("--tiers", nargs="+", default=None,
                        help="Tiers to check (default: all found)")
    args = parser.parse_args()

    inv_base = args.inventories_dir.resolve()
    output_dir = args.output.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    # Discover tiers
    if args.tiers:
        tiers_to_check = args.tiers
    else:
        tiers_to_check = [t for t in TIER_ORDER
                          if (inv_base / t).is_dir()]

    if not tiers_to_check:
        print(f"ERROR: No tier directories found in {inv_base}")
        print(f"Expected subdirectories named: {', '.join(TIER_ORDER)}")
        print("If your inventory files are elsewhere, provide the path "
              "containing the tier subdirectories.")
        sys.exit(1)

    print(f"Inventories: {inv_base}")
    print(f"Tiers: {', '.join(tiers_to_check)}")
    print(f"Output: {output_dir}")
    print()

    # Load all tiers
    all_inventories = {}
    for tier_name in tiers_to_check:
        tier_dir = inv_base / tier_name
        print(f"  Loading {tier_name}...")
        inv = load_inventory(tier_dir)
        all_inventories[tier_name] = inv
        print(f"    {len(inv['entities'])} entities, "
              f"{len(inv['areas'])} areas, "
              f"{len(inv['domains'])} domains")
    print()

    # Run checks
    all_findings = {}

    # Per-tier checks
    for tier_name in tiers_to_check:
        inv = all_inventories[tier_name]
        section = f"{tier_name.title()} Tier"

        findings = []
        findings.extend(check_entity_counts(inv, tier_name))
        findings.extend(check_area_counts(inv, tier_name))
        findings.extend(check_domain_count(inv, tier_name))
        findings.extend(check_duplicate_entity_ids(inv))
        findings.extend(check_area_references(inv))
        findings.extend(check_meta_states(inv, tier_name))
        findings.extend(check_null_area_entities(inv))
        findings.extend(check_duplicate_friendly_names(inv))
        findings.extend(check_light_capability_distribution(inv, tier_name))
        findings.extend(check_device_class_breadth(inv, tier_name))
        findings.extend(check_area_density(inv))
        findings.extend(check_moved_but_not_renamed(inv))
        findings.extend(check_companion_groups(inv))

        all_findings[section] = findings

    # Cross-tier checks
    if len(all_inventories) > 1:
        cross_findings = []
        cross_findings.extend(check_subset_chain(all_inventories))
        cross_findings.extend(check_entity_identity_preservation(all_inventories))
        all_findings["Cross-Tier Verification"] = cross_findings

    # Generate report
    print("Generating report...")
    report = format_report(all_findings, all_inventories)
    report_path = output_dir / "audit-inventory.md"
    with open(report_path, "w") as f:
        f.write("\n".join(report) + "\n")
    print(f"Report: {report_path}")

    total_fail = sum(1 for findings in all_findings.values()
                     for sev, _, _ in findings if sev == "FAIL")
    sys.exit(1 if total_fail > 0 else 0)

# Inventory ↔ Test Case Cross-Reference Analysis Guide

**Purpose:** How to audit a tier's inventory source files and test case source files
for mutual consistency. Focuses on issues that only surface when both are read
together, particularly derivation drift that is invisible when auditing each in
isolation.

**When to run:** Once, after generating or significantly modifying a tier's inventory
or test case data. Re-run only when source files change (e.g. after generating
expanded test cases or re-deriving a tier).

**Audience:** An LLM agent or human validating that a tier's source data is ready
for benchmark use. Run this before running `inspect eval` for the first time with
a new or updated dataset.

**Script location:** `scripts/assemble_tier.py` in the repo root. Run via
`uv run scripts/assemble_tier.py`.

**See also:**
- `inventory-analysis-guide.md` — auditing inventory source files in isolation
- `test-case-analysis-guide.md` — auditing test case source files in isolation
  (Phase C covers some cross-reference checks; this guide goes deeper on
  derivation drift specifically)
- `assemble_tier.py` — `--validate` flag performs the automated reference check
  (Step 1 of this guide)
- `derivation-guide.md` — tier derivation rules (essential context for drift detection)

---

## Why This Guide Exists

The per-domain source files (inventory YAMLs and test case NDJSONs) are authored
and derived independently. Each is internally consistent. The existing analysis
guides audit them separately.

Issues only visible when reading both together include:

- **Derivation drift:** When a smaller tier is derived, entities are removed or
  reassigned to different areas. Test case metadata (`target_areas`, tool call
  `area` arguments) may still reference the old area from the larger tier.
- **Capability mismatches:** A test case expects a tool argument (e.g. `color_temp`,
  `percentage`, `position`) that the target entity's `supported_color_modes` or
  `supported_features` doesn't actually support in this tier.
- **State assumption drift:** A test case assumes a specific entity state (e.g. a
  lock is locked, a cover is open) but the inventory has that entity in a
  different state.
- **Semantic utterance gaps:** The utterance implies an entity or capability that
  exists in the enormous tier but was removed during derivation.
- **Alternative coherence:** An alternative `expected_tool_calls` path references
  an entity that doesn't exist or has different capabilities in this tier.

`assemble_tier.py --validate` catches hard reference failures (entity_ids and area
names that don't exist at all). This guide catches subtler issues that pass the
reference check but are still wrong.

---

## Prerequisites

### Source files

All analysis in this guide reads directly from the per-domain source files:

```
test_data/
  inventories/{tier}/
    areas.yaml              ← area id→name mapping
    {domain}.yaml           ← entities for each domain
  test_cases/{tier}/
    {domain}_test_cases.ndjson
    cross_domain_test_cases.ndjson
    utility_test_cases.ndjson
```

No assembled files are needed. Fixes go back into these source files.

**Entity lookup pattern:** The domain is the prefix before the dot in any
`entity_id`. Given `lock.front_door_lock`, open `inventories/{tier}/lock.yaml`
and find the entry with `entity_id: lock.front_door_lock`.

### Working directory

```
scratch/tmp/audit-crossref/{tier}/
```

### Step types

- **🔧 Script step** — Run `assemble_tier.py --validate`. Static analysis,
  no LLM judgment needed.
- **🧠 LLM analysis step** — Requires reading source files, applying derivation
  context, and exercising judgment.

---

## Severity Definitions

| Level | Meaning | Examples |
|-------|---------|---------|
| **FAIL** | Test case cannot be correctly evaluated against this inventory. Blocks usage. | Tool call `name` argument doesn't match any entity friendly name; `area` argument references wrong area for the target entity; entity capability doesn't support the tested argument |
| **WARN** | Test case may produce misleading results. Investigate before accepting. | Entity state doesn't match what the test assumes; alternative references an entity absent from this tier; utterance implies a removed entity |
| **INFO** | Observation worth documenting. No immediate action required. | Drift documented and accepted; state assumption noted for T3 scoring context |

Every finding includes a reasoning line: what data caused it, what the downstream
effect is, and what the fix is.

---

## Step 1: Automated Reference Check (🔧 Script)

```bash
uv run scripts/assemble_tier.py --base-dir test_data/ --tier {tier} --validate
```

Loads and assembles all source data in memory, checks:
- Every `metadata.target_entities` entity_id exists in the tier's inventory.
- Every `metadata.target_areas` area name exists in the tier's inventory.

Exits without writing any files.

**If this step fails:** Stop. Fix the source files and re-run `--validate`. The
remaining steps assume this passes cleanly.

**Output:** Pass/fail to stdout. On failure: list of unresolved references with
case IDs.

---

## Step 2: Area Remapping Drift (🧠 LLM Analysis)

The most common derivation drift issue. When a smaller tier drops an area, entities
in that area are moved to a different area or given `area: null`. The derivation
process may not update test case metadata to match.

### How to check:

1. Load `inventories/{tier}/areas.yaml` to build an id→name map.
2. For each test case file, read cases that have both `target_entities` and
   `target_areas` in metadata.
3. For each entity_id in `target_entities`:
   - Derive domain from the prefix (e.g. `binary_sensor.patio_window_contact`
     → `binary_sensor`)
   - Open `inventories/{tier}/binary_sensor.yaml`, find the entity
   - Read its `area` field (an id like `back_yard`), look up the name (`Back Yard`)
   - Compare against `target_areas` in the test case
4. Also check `expected_tool_calls[].arguments.area` against the entity's actual
   area — an area command targeting the wrong area silently reaches no entities.

**Flag if:** Entity's actual area doesn't match `target_areas` or the tool call's
`area` argument. This is derivation drift.

**Canonical example (the bug this analysis caught):**

```
Test case:  target_areas: ['Patio']
Entity:     binary_sensor.patio_window_contact → area: back_yard → 'Back Yard'
Finding:    FAIL — test says Patio, entity is in Back Yard in this tier
Fix:        Update target_areas to ['Back Yard'] in binary_sensor_test_cases.ndjson
```

**Also flag:** Null-area drift — entity's area became `null` during derivation but
test case still uses area-based targeting in `expected_tool_calls`. The tool call
would reach no entities. Only flag when the entity was area-assigned in a larger
tier (null-area is intentional for portable devices and speaker groups).

**Write findings to:** `<working_dir>/step2-area-drift.md`

---

## Step 3: Tool Call Argument Semantic Validation (🧠 LLM Analysis)

Step 1 confirms entity_ids and area names exist. This step checks that argument
*values* are semantically correct for the specific entity being targeted.

### 3a: Friendly name matching

For each test case, read every `expected_tool_calls[].arguments.name` (and
`name_any_of` lists) in both primary and alternative tool calls.

- Look up that name in the entity's domain YAML (case-insensitive match on the
  `name:` field).
- **Flag if not found:** Name confabulation — the test case was written with a
  name constructed from the entity_id rather than copied from the inventory.
  Common pattern: `light.kitchen_counter_strip` → confabulated "Kitchen Counter
  Strip" when the actual `name:` is "Kitchen Hue Strip".
- **Flag if found but wrong area:** Entity with that name exists but is in a
  different area than the test's `target_areas` or `area` argument.

Apply the same check to alternatives — confabulated names appear there too.

### 3b: Capability-argument coherence

For test cases using domain-specific tool arguments, verify the target entity
supports the relevant capability in its `attributes`:

| Tool argument | Check in entity attributes |
|---------------|---------------------------|
| `brightness` (HassLightSet) | `supported_color_modes` includes `brightness`, `color_temp`, or any rgb variant |
| `color_temp` (HassLightSet) | `supported_color_modes` includes `color_temp` |
| `rgb_color` / `hs_color` (HassLightSet) | `supported_color_modes` includes `hs`, `rgb`, `rgbw`, or `rgbww` |
| `position` (HassSetPosition) | cover with position-capable `device_class` (blind, curtain, shade) — not binary (garage_door) |
| `percentage` (HassFanSetSpeed) | fan entity with `percentage` in `supported_features` |
| `volume_level` (HassSetVolume) | media_player entity |
| `media_class` (HassMediaSearchAndPlay) | media_player with search capability |

**Flag if:** The test calls a tool with an argument the entity can't support. If the
model produces the "correct" tool call but HA would reject it, the benchmark is
testing something that would fail in production.

**Write findings to:** `<working_dir>/step3-tool-args.md`

---

## Step 4: Entity State Coherence (🧠 LLM Analysis)

Some test cases implicitly or explicitly assume a specific entity state. Check that
the inventory's entity states are consistent with those assumptions.

### What to look for:

- **Lock/unlock assumptions:** A test for `HassTurnOff` (unlock) — does the
  inventory show that lock as `state: locked`? An already-unlocked lock is valid
  to test but exercises a less interesting path.

- **Error/unavailable state cases:** Test cases targeting an entity in `unavailable`
  or `error` state — verify that entity actually has that state in this tier's
  domain YAML. If it was replaced during derivation with an entity in `state: "off"`,
  the test case loses its purpose.

- **Companion entity coherence:** For multi-entity device groups (e.g. a 3D printer:
  switch + temperature sensors), check that states are consistent across the domain
  YAMLs. A switch in `state: "off"` with a nozzle temperature sensor reading 215°C
  is incoherent and may produce misleading T3 scores.

### Reasoning principles:

- **State coherence is a T3 concern more than T1/T2.** Tool selection and argument
  correctness don't depend on entity state. Quality of the model's explanation does.
  Flag as INFO unless the state assumption is fundamental to the test's purpose.

- **Fix test cases or document the mismatch, not the inventory.** Entity states
  provide realistic variety. If a test assumes a state the inventory doesn't have,
  update the test case note or the test case — not the inventory state.

**Write findings to:** `<working_dir>/step4-state-coherence.md`

---

## Step 5: Utterance-Inventory Semantic Alignment (🧠 LLM Analysis)

Sample 20-30 utterances across the tier's NDJSON files. For each, mentally resolve
the utterance against the tier's inventory as the model would.

### What to look for:

- **Implied-but-absent entities:** The utterance references a device that was present
  in the enormous tier but removed during derivation. Example: "pause the patio
  speaker" when this tier has no Patio area and no patio media_player entity. The
  model should respond with error/clarification, but if `expected_tool_calls` still
  references the removed entity, the expected answer is impossible in this tier.

- **Utterance resolves differently at this scale:** An utterance designed for
  enormous (130 lights → real disambiguation challenge) may be trivially resolvable
  at small (6 lights → only one match). If the test case is rated `complexity:
  ambiguous` but this tier makes it unambiguous, flag for metadata update. Don't
  change `expected_tool_calls`.

- **Area name in utterance vs areas in inventory:** "Turn off the patio lights"
  when this tier has no Patio area. The model should return error/clarification,
  but if `expected_tool_calls` targets Patio, the expected answer is unreachable.

### Reasoning principles:

- **Sample broadly, not deeply.** If the entity name appears verbatim in both the
  utterance and the inventory, move on. Focus on indirect references ("the TV",
  "the thermostat") where the model must resolve by area or domain.

- **Semantic gaps are harder than reference gaps.** `--validate` catches "entity_id
  doesn't exist." This step catches "utterance implies something that doesn't exist
  and the expected answer assumes it does."

**Write findings to:** `<working_dir>/step5-utterance-alignment.md`

---

## Step 6: Alternative Coherence in This Tier (🧠 LLM Analysis)

Alternatives are authored at the enormous tier level and inherited by smaller tiers.
They may reference entities, areas, or capabilities not present in this tier.

### What to look for:

- **Alternative names a removed entity:** Look up the alternative's `name` argument
  in this tier's domain YAMLs. If it doesn't exist, the alternative is unreachable
  in this tier. Flag as WARN — it won't cause false positives (the model won't
  produce it) but is dead data worth documenting.

- **Alternative quality rating no longer applies:** An alternative rated `degraded`
  because it uses a smart plug instead of the media player — does that switch entity
  still exist in this tier's switch.yaml? If not, the alternative is unreachable.

- **Area drift in alternatives:** Apply the same area remapping check from Step 2
  to alternative tool call `area` arguments.

### Reasoning principles:

- **Don't remove alternatives from source files based on tier-specific analysis.**
  An alternative unreachable in small but valid in enormous is correct by design —
  the source file is fine. Only flag if the alternative is unreachable across ALL
  tiers (truly dead data).

**Write findings to:** `<working_dir>/step6-alternative-coherence.md`

---

## Step 7: Consolidation

Merge findings from Steps 1-6 into a final report for this tier.

### Structure:

```markdown
# Cross-Reference Audit — {tier} Tier

## Summary
- Script validation (Step 1): PASS / FAIL (N unresolved references)
- Area drift (Step 2): N FAIL, N WARN
- Tool args (Step 3): N FAIL, N WARN
- State coherence (Step 4): N INFO
- Utterance alignment (Step 5): N WARN
- Alternative coherence (Step 6): N WARN

## Blockers (FAIL)
[Name confabulations, capability mismatches, null-area drift with area targeting]

## Concerns (WARN)
[State coherence notes, utterance alignment gaps, unreachable alternatives]

## Derivation Drift Summary
[Each drift finding: what changed between tiers, fix location (inventory source
or test case source), or accepted with documented reasoning]

## Recommended Actions
[Fix N items in source files, re-validate.
Accept N items with documented reasoning.
Investigate N items before deciding.]
```

**Write to:** `<working_dir>/audit-crossref-{tier}-final.md`

---

## Cross-Tier Consistency Check (Optional, 🧠 LLM Analysis)

If auditing multiple tiers, compare findings after completing per-tier analysis.

### What to look for:

- **Drift isolated to one tier:** If `patio_window_contact` has an area mismatch
  in `large` but not `medium`, the derivation handled it correctly for one tier and
  missed it for another.

- **Monotonic case counts:** Count lines across each tier's NDJSON files.
  enormous ≥ large ≥ medium ≥ small. If a smaller tier has more cases, derivation
  added rather than only subtracted.

- **All-tier cases identical across tiers:** Cases with `inventory_tier: "all"`
  should have identical `utterance`, `expected_tool_calls`, and `metadata` in every
  tier's source files. If they differ, the source files have diverged.

**Write to:** `<working_dir>/audit-crossref-cross-tier.md`

---

## Appendix: What This Guide Does NOT Cover

- **Per-domain source file quality in isolation.** Use `inventory-analysis-guide.md`
  and `test-case-analysis-guide.md` for those audits.
- **Benchmark execution results.** This guide validates pre-run data quality.
  Post-run failure analysis uses `docs/failure-patterns.md`.
- **Inventory or test case generation.** Use the generation guides for that.
- **Automated fixes.** This guide surfaces issues; fixes go into the per-domain
  source files and are re-validated with `--validate`.
- **Assembly.** That is `assemble_tier.py`'s concern, run separately when producing
  files for a benchmark run.

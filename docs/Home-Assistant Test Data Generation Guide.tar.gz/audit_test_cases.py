#!/usr/bin/env python3
"""
Audit test case NDJSON files: internal consistency, cross-reference with
inventory, and coverage matrix.

Usage:
    python3 audit_test_cases.py <test_cases_dir> <inventories_dir> \
        [--output <dir>] [--phase internal|crossref|coverage|all]

    <test_cases_dir>    Path containing tier subdirs with *_test_cases.ndjson files.
    <inventories_dir>   Path containing tier subdirs with *.yaml files.
    --output            Where to write report(s) (default: current directory).
    --phase             Which phase to run (default: all).

Output:
    audit-test-cases-internal.md   — Phase A: internal consistency
    audit-test-cases-crossref.md   — Phase B: cross-reference with inventory
    audit-test-cases-coverage.md   — Phase C: coverage matrix

Severity levels:
    FAIL    Hard requirement violated. Blocks usage.
    WARN    Quality concern or missed target. Worth investigating.
    INFO    Observation or potential issue. Be aware.
"""

import argparse
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

import yaml

TIER_ORDER = ["enormous", "large", "medium", "small"]

VALID_RESPONSE_TYPES = {"action_done", "query_response", "text_response",
                        "error", "clarification"}
VALID_COMPLEXITY = {"simple", "moderate", "complex", "ambiguous", "edge_case"}

REQUIRED_FIELDS = {"id", "utterance", "expected_tool_calls",
                   "expected_response_type", "inventory_tier",
                   "metadata"}
REQUIRED_METADATA = {"complexity", "target_entities", "case_key"}


# ── Loading ──

def load_test_cases(tier_dir: Path) -> list[dict]:
    """Load all NDJSON test cases from a tier directory."""
    cases = []
    for f in sorted(tier_dir.glob("*_test_cases.ndjson")):
        domain = f.stem.replace("_test_cases", "")
        with open(f) as fh:
            for line_num, line in enumerate(fh, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    case = json.loads(line)
                    case["_source_file"] = f.name
                    case["_source_domain"] = domain
                    case["_line_num"] = line_num
                    cases.append(case)
                except json.JSONDecodeError as e:
                    cases.append({
                        "_parse_error": str(e),
                        "_source_file": f.name,
                        "_line_num": line_num,
                    })
    return cases


def load_inventory(tier_dir: Path) -> dict:
    """Load inventory (same as audit_inventory.py)."""
    result = {
        "entity_ids": set(),
        "entity_names": set(),
        "area_names": set(),
        "area_ids": set(),
        "entities_by_domain": defaultdict(list),
        "domains": set(),
        "entities": [],
    }

    areas_path = tier_dir / "areas.yaml"
    if areas_path.exists():
        with open(areas_path) as f:
            data = yaml.safe_load(f)
        if data and "areas" in data:
            for a in data["areas"]:
                result["area_names"].add(a.get("name", ""))
                result["area_ids"].add(a.get("id", ""))

    for yaml_file in sorted(tier_dir.glob("*.yaml")):
        if yaml_file.name == "areas.yaml":
            continue
        domain = yaml_file.stem
        with open(yaml_file) as f:
            data = yaml.safe_load(f)
        if data and "entities" in data:
            for e in data["entities"]:
                eid = e.get("entity_id", "")
                name = e.get("name", "")
                if eid:
                    result["entity_ids"].add(eid)
                if name:
                    result["entity_names"].add(name)
                result["entities_by_domain"][domain].append(e)
                result["domains"].add(domain)
                result["entities"].append(e)

    return result


# ── Phase A: Internal consistency ──

def phase_internal(all_cases: dict) -> list:
    """Check internal consistency of test case NDJSON files."""
    findings = []

    for tier_name in TIER_ORDER:
        cases = all_cases.get(tier_name, [])
        if not cases:
            continue

        findings.append(("INFO", f"--- {tier_name.upper()} TIER "
                        f"({len(cases)} cases) ---", ""))

        # Parse errors
        parse_errors = [c for c in cases if "_parse_error" in c]
        if parse_errors:
            for c in parse_errors:
                findings.append(("FAIL",
                    f"{c['_source_file']} L{c['_line_num']}: "
                    f"JSON parse error: {c['_parse_error']}",
                    "Invalid JSON prevents all further analysis on this case."))

        valid_cases = [c for c in cases if "_parse_error" not in c]

        # Required fields
        for c in valid_cases:
            case_id = c.get("id", f"{c.get('_source_file')}:L{c.get('_line_num')}")
            missing = REQUIRED_FIELDS - set(c.keys())
            if missing:
                findings.append(("FAIL",
                    f"{case_id}: Missing required fields: {', '.join(sorted(missing))}",
                    "All test cases need these fields for the benchmark harness."))

            meta = c.get("metadata", {})
            if meta:
                missing_meta = REQUIRED_METADATA - set(meta.keys())
                if missing_meta:
                    findings.append(("WARN",
                        f"{case_id}: Missing metadata fields: "
                        f"{', '.join(sorted(missing_meta))}",
                        "case_key is required for cross-tier analysis. "
                        "complexity and target_entities are needed for scoring."))

        # Response type validation
        for c in valid_cases:
            rt = c.get("expected_response_type")
            if rt and rt not in VALID_RESPONSE_TYPES:
                findings.append(("WARN",
                    f"{c.get('id', '?')}: Unknown response type '{rt}'.",
                    f"Valid types: {', '.join(sorted(VALID_RESPONSE_TYPES))}"))

        # Complexity validation
        for c in valid_cases:
            cx = c.get("metadata", {}).get("complexity")
            if cx and cx not in VALID_COMPLEXITY:
                findings.append(("WARN",
                    f"{c.get('id', '?')}: Unknown complexity '{cx}'.",
                    f"Valid values: {', '.join(sorted(VALID_COMPLEXITY))}"))

        # case_key uniqueness within tier
        key_counts = Counter(
            c.get("metadata", {}).get("case_key", "")
            for c in valid_cases
            if c.get("metadata", {}).get("case_key"))
        dupes = {k: n for k, n in key_counts.items() if n > 1}
        if dupes:
            for k, n in sorted(dupes.items()):
                findings.append(("FAIL",
                    f"Duplicate case_key '{k}' appears {n} times in "
                    f"{tier_name} tier.",
                    "case_key must be unique within a tier. "
                    "Cross-tier joins depend on uniqueness."))

        # inventory_file consistency
        inv_files = set(c.get("inventory_file") for c in valid_cases
                        if c.get("inventory_file") is not None)
        tier_specific = [f for f in inv_files if f]
        if len(set(tier_specific)) > 1:
            findings.append(("WARN",
                f"Multiple inventory_file paths in {tier_name} tier: "
                f"{', '.join(sorted(set(tier_specific)))}",
                "All entity-specific cases in a tier should reference the "
                "same combined.yaml path."))

        # Per-file case counts
        file_counts = Counter(c.get("_source_file") for c in valid_cases)
        findings.append(("INFO",
            f"Per-file counts: {', '.join(f'{k}={v}' for k, v in sorted(file_counts.items()))}",
            ""))

        # Response type distribution
        rt_counts = Counter(c.get("expected_response_type") for c in valid_cases)
        findings.append(("INFO",
            f"Response types: {', '.join(f'{k}={v}' for k, v in sorted(rt_counts.items()))}",
            ""))

        # Complexity distribution
        cx_counts = Counter(c.get("metadata", {}).get("complexity")
                           for c in valid_cases)
        findings.append(("INFO",
            f"Complexity: {', '.join(f'{k}={v}' for k, v in sorted(cx_counts.items()) if k)}",
            ""))

        # Empty tool_calls + non-error/clarification/text response
        for c in valid_cases:
            etc = c.get("expected_tool_calls", [])
            rt = c.get("expected_response_type", "")
            if etc and rt in ("error", "text_response"):
                findings.append(("WARN",
                    f"{c.get('id', '?')}: Has tool_calls but response_type "
                    f"is '{rt}'.",
                    "Error/text_response cases should have empty "
                    "expected_tool_calls."))
            if not etc and rt == "action_done":
                findings.append(("WARN",
                    f"{c.get('id', '?')}: No tool_calls but response_type "
                    f"is 'action_done'.",
                    "Action_done cases should have expected tool calls."))

    return findings


# ── Phase B: Cross-reference with inventory ──

def phase_crossref(all_cases: dict, all_inventories: dict) -> list:
    """Cross-reference test cases against inventory."""
    findings = []

    # Per-tier entity reference checks
    for tier_name in TIER_ORDER:
        cases = all_cases.get(tier_name, [])
        inv = all_inventories.get(tier_name)
        if not cases or not inv:
            continue

        valid_cases = [c for c in cases if "_parse_error" not in c]

        findings.append(("INFO", f"--- {tier_name.upper()} TIER "
                        f"({len(valid_cases)} cases) ---", ""))

        # Check target_entities
        entity_errors = 0
        for c in valid_cases:
            targets = c.get("metadata", {}).get("target_entities", [])
            for eid in targets:
                if eid and eid not in inv["entity_ids"]:
                    entity_errors += 1
                    if entity_errors <= 15:
                        findings.append(("FAIL",
                            f"{c.get('id', '?')}: target_entity '{eid}' "
                            f"not in {tier_name} inventory.",
                            "Entity ID confabulation or derivation error."))
        if entity_errors > 15:
            findings.append(("FAIL",
                f"... and {entity_errors - 15} more entity ref errors.", ""))
        elif entity_errors == 0:
            findings.append(("INFO",
                f"All target_entities verified for {tier_name}.", ""))

        # Check names in tool_calls
        name_errors = 0
        for c in valid_cases:
            for tc in c.get("expected_tool_calls", []):
                args = tc.get("arguments", {})
                name = args.get("name")
                if name and name not in inv["entity_names"]:
                    name_errors += 1
                    if name_errors <= 15:
                        findings.append(("FAIL",
                            f"{c.get('id', '?')}: tool_call name '{name}' "
                            f"not in {tier_name} inventory.",
                            "Entity name confabulation."))
                nao = args.get("name_any_of", [])
                for n in nao:
                    if n and n not in inv["entity_names"]:
                        name_errors += 1
                        if name_errors <= 15:
                            findings.append(("FAIL",
                                f"{c.get('id', '?')}: name_any_of '{n}' "
                                f"not in {tier_name} inventory.",
                                "Entity name confabulation."))

            # Also check alternatives
            for alt in c.get("alternative_expected_tool_calls", []):
                for tc in alt.get("tool_calls", []):
                    args = tc.get("arguments", {})
                    name = args.get("name")
                    if name and name not in inv["entity_names"]:
                        name_errors += 1
                        if name_errors <= 15:
                            findings.append(("FAIL",
                                f"{c.get('id', '?')}: alt name '{name}' "
                                f"not in {tier_name} inventory.",
                                "Entity name confabulation in alternative."))
                    nao = args.get("name_any_of", [])
                    for n in nao:
                        if n and n not in inv["entity_names"]:
                            name_errors += 1
                            if name_errors <= 15:
                                findings.append(("FAIL",
                                    f"{c.get('id', '?')}: alt name_any_of "
                                    f"'{n}' not in {tier_name} inventory.",
                                    "Entity name confabulation in alternative."))

        if name_errors > 15:
            findings.append(("FAIL",
                f"... and {name_errors - 15} more name errors.", ""))
        elif name_errors == 0:
            findings.append(("INFO",
                f"All tool_call names verified for {tier_name}.", ""))

        # Check areas in tool_calls
        area_errors = 0
        for c in valid_cases:
            for tc in c.get("expected_tool_calls", []):
                area = tc.get("arguments", {}).get("area")
                if area and area not in inv["area_names"]:
                    area_errors += 1
                    if area_errors <= 10:
                        findings.append(("FAIL",
                            f"{c.get('id', '?')}: area '{area}' "
                            f"not in {tier_name} inventory.",
                            "Area reference to nonexistent area."))
        if area_errors == 0:
            findings.append(("INFO",
                f"All tool_call areas verified for {tier_name}.", ""))

    # Cross-tier: case_key subset chain
    findings.append(("INFO", "--- CROSS-TIER: case_key subset chain ---", ""))
    pairs = [("small", "medium"), ("medium", "large"), ("large", "enormous")]
    total_orphans = 0

    for child_name, parent_name in pairs:
        child_cases = all_cases.get(child_name, [])
        parent_cases = all_cases.get(parent_name, [])
        if not child_cases or not parent_cases:
            continue

        child_keys = set(c.get("metadata", {}).get("case_key", "")
                         for c in child_cases if c.get("metadata", {}).get("case_key"))
        parent_keys = set(c.get("metadata", {}).get("case_key", "")
                          for c in parent_cases if c.get("metadata", {}).get("case_key"))

        orphans = child_keys - parent_keys
        if orphans:
            total_orphans += len(orphans)
            findings.append(("FAIL",
                f"case_key subset violation: {len(orphans)} keys in "
                f"{child_name} not in {parent_name}.",
                f"Orphans: {', '.join(sorted(list(orphans)[:10]))}. "
                f"A case dropped from a larger tier cannot reappear "
                f"in a smaller tier via retargeting."))
        else:
            findings.append(("INFO",
                f"case_key subset verified: {child_name} "
                f"({len(child_keys)}) ⊂ {parent_name} ({len(parent_keys)}).",
                ""))

    # Cross-tier: case count monotonic decrease
    counts = [(t, len(all_cases.get(t, []))) for t in TIER_ORDER
              if t in all_cases]
    if len(counts) > 1:
        is_mono = all(counts[i][1] >= counts[i+1][1]
                      for i in range(len(counts) - 1))
        count_str = " > ".join(f"{t}={n}" for t, n in counts)
        if is_mono:
            findings.append(("INFO",
                f"Case counts monotonically decrease: {count_str}.", ""))
        else:
            findings.append(("WARN",
                f"Case counts NOT monotonically decreasing: {count_str}.",
                "Expected Enormous ≥ Large ≥ Medium ≥ Small."))

    # Cross-tier: retarget detection
    findings.append(("INFO", "--- CROSS-TIER: retarget detection ---", ""))

    enormous_cases = all_cases.get("enormous", [])
    if enormous_cases:
        enormous_by_key = {}
        for c in enormous_cases:
            ck = c.get("metadata", {}).get("case_key", "")
            if ck:
                enormous_by_key[ck] = c

        retarget_count = 0
        for tier_name in ["large", "medium", "small"]:
            tier_cases = all_cases.get(tier_name, [])
            for c in tier_cases:
                ck = c.get("metadata", {}).get("case_key", "")
                if ck and ck in enormous_by_key:
                    e_utt = enormous_by_key[ck].get("utterance", "")
                    t_utt = c.get("utterance", "")
                    if e_utt != t_utt:
                        retarget_count += 1

        findings.append(("INFO",
            f"{retarget_count} retargeted cases detected across derived tiers.",
            "Review retargets with LLM analysis for device-type drift."))

    # Empty file validation
    findings.append(("INFO", "--- EMPTY FILE VALIDATION ---", ""))
    for tier_name in TIER_ORDER:
        tier_dir_cases = all_cases.get(tier_name, [])
        inv = all_inventories.get(tier_name)
        if not inv:
            continue

        # Find which domain files are empty (0 cases)
        file_counts = Counter(c.get("_source_file") for c in tier_dir_cases
                             if "_parse_error" not in c)

        # Check all expected files
        inv_domains = inv["domains"]
        for domain in sorted(inv_domains):
            fname = f"{domain}_test_cases.ndjson"
            count = file_counts.get(fname, 0)
            if count == 0:
                findings.append(("WARN",
                    f"{tier_name}/{fname}: 0 test cases but {domain} "
                    f"domain exists in inventory ({len(inv['entities_by_domain'].get(domain, []))} entities).",
                    "A domain with entities but no test cases is a coverage gap."))

    return findings


# ── Phase C: Coverage matrix ──

def phase_coverage(all_cases: dict, all_inventories: dict) -> list:
    """Generate coverage matrix: inventory features → test case presence."""
    findings = []

    # Focus on enormous tier for feature coverage
    enormous_cases = [c for c in all_cases.get("enormous", [])
                      if "_parse_error" not in c]
    enormous_inv = all_inventories.get("enormous")

    if not enormous_cases or not enormous_inv:
        findings.append(("WARN", "Cannot generate coverage matrix — "
                        "enormous tier data missing.", ""))
        return findings

    # Build tool × domain matrix
    findings.append(("INFO", "--- TOOL × DOMAIN COVERAGE MATRIX ---", ""))

    tool_by_domain = defaultdict(set)
    for c in enormous_cases:
        domain = c.get("_source_domain", "unknown")
        for tc in c.get("expected_tool_calls", []):
            tool = tc.get("name", "")
            if tool:
                tool_by_domain[domain].add(tool)

    all_tools = sorted(set(t for tools in tool_by_domain.values() for t in tools))
    all_domains = sorted(tool_by_domain.keys())

    findings.append(("INFO",
        f"Tool × Domain: {len(all_tools)} tools across {len(all_domains)} domain files.",
        ""))

    # Check specific tool coverage expectations
    # These are tools that should be tested per domain (from reverse analysis)
    generic_tools = {"HassTurnOn", "HassTurnOff", "HassToggle", "HassGetState"}
    actionable_domains = {"light", "switch", "cover", "lock", "fan", "climate",
                         "media_player", "vacuum", "valve"}

    for domain in sorted(actionable_domains & set(all_domains)):
        domain_tools = tool_by_domain.get(domain, set())
        for tool in sorted(generic_tools):
            if tool not in domain_tools:
                # Check if it makes sense for this domain
                if tool == "HassToggle" and domain in {"vacuum", "lawn_mower", "valve"}:
                    continue  # Toggle doesn't apply to these
                findings.append(("WARN",
                    f"Tool gap: {tool} not tested in {domain} domain file.",
                    "Generic tools should ideally be tested per actionable domain. "
                    "May be covered in cross_domain instead."))

    # Duplicate friendly name coverage
    findings.append(("INFO", "--- DUPLICATE NAME DISAMBIGUATION COVERAGE ---", ""))

    name_groups = defaultdict(list)
    for e in enormous_inv["entities"]:
        name = e.get("name", "")
        if name:
            name_groups[name].append(e)

    dupe_groups = {name: ents for name, ents in name_groups.items()
                   if len(ents) > 1}

    # Check if each dupe group has a test case targeting it
    case_target_names = set()
    for c in enormous_cases:
        # Collect names from utterances and tool calls for rough matching
        utt = c.get("utterance", "").lower()
        for tc in c.get("expected_tool_calls", []):
            name = tc.get("arguments", {}).get("name", "")
            if name:
                case_target_names.add(name)
        # Also check metadata notes for disambiguation hints
        notes = c.get("metadata", {}).get("notes", "").lower()
        if "disambig" in notes or "duplicate" in notes or "ambig" in notes:
            for te in c.get("metadata", {}).get("target_entities", []):
                case_target_names.add(te)

    for name, ents in sorted(dupe_groups.items()):
        # Check if any test case references this entity by name
        covered = name in case_target_names
        areas = [e.get("area", "null") for e in ents]
        if not covered:
            findings.append(("WARN",
                f"Duplicate name '{name}' × {len(ents)} "
                f"(areas: {', '.join(str(a) for a in areas)}) "
                f"— no test case found targeting this group.",
                "Each duplicate name group should ideally have a "
                "disambiguation test case."))
        else:
            findings.append(("INFO",
                f"Duplicate name '{name}' × {len(ents)} — covered.", ""))

    # Unavailable entity coverage
    findings.append(("INFO", "--- UNAVAILABLE ENTITY COVERAGE ---", ""))

    actionable_unavailable = [
        e for e in enormous_inv["entities"]
        if e.get("state") == "unavailable"
        and e.get("_domain") in actionable_domains
    ]

    for e in actionable_unavailable:
        eid = e.get("entity_id", "")
        covered = any(eid in c.get("metadata", {}).get("target_entities", [])
                      for c in enormous_cases)
        if not covered:
            findings.append(("WARN",
                f"Actionable unavailable entity '{eid}' has no test case.",
                "Unavailable actionable entities need 'attempt action on "
                "offline device' test cases (Step 8d)."))
        else:
            findings.append(("INFO",
                f"Actionable unavailable entity '{eid}' — covered.", ""))

    # Unknown/jammed/error state coverage
    findings.append(("INFO", "--- UNUSUAL STATE COVERAGE ---", ""))

    unusual_states = {"unknown", "jammed", "error"}
    unusual_entities = [e for e in enormous_inv["entities"]
                        if e.get("state") in unusual_states]

    for e in unusual_entities:
        eid = e.get("entity_id", "")
        state = e.get("state")
        covered = any(eid in c.get("metadata", {}).get("target_entities", [])
                      for c in enormous_cases)
        if not covered:
            findings.append(("WARN",
                f"Entity '{eid}' (state: {state}) has no test case.",
                f"Entities in unusual states ({state}) are valuable edge "
                f"case test targets."))
        else:
            findings.append(("INFO",
                f"Entity '{eid}' (state: {state}) — covered.", ""))

    # Companion group coverage
    findings.append(("INFO", "--- COMPANION GROUP COVERAGE ---", ""))

    # Simple keyword-based companion detection (same as audit_inventory)
    common_words = {"the", "a", "an", "sensor", "binary_sensor", "switch",
                    "light", "cover", "lock", "climate", "fan",
                    "media_player", "vacuum", "lawn_mower", "weather",
                    "todo", "valve"}

    # Exclude area-name fragments to avoid grouping all entities in an area
    area_words = set()
    for area_id in enormous_inv.get("area_ids", set()):
        for word in area_id.lower().split("_"):
            if len(word) > 2:
                area_words.add(word)
    exclude_words = common_words | area_words

    stem_to_entities = defaultdict(list)
    for e in enormous_inv["entities"]:
        eid = e.get("entity_id", "")
        if "." in eid:
            stem = eid.split(".", 1)[1]
        else:
            stem = eid
        words = set(stem.lower().split("_")) - exclude_words
        for word in words:
            if len(word) > 3:
                stem_to_entities[word].append(e)

    companion_groups = {}
    for word, entities in stem_to_entities.items():
        domains = set(e.get("_domain") for e in entities)
        if len(domains) >= 2:
            seen = set()
            unique = []
            for e in entities:
                eid = e.get("entity_id")
                if eid not in seen:
                    seen.add(eid)
                    unique.append(e)
            if len(set(e.get("_domain") for e in unique)) >= 2:
                key = tuple(sorted(e.get("entity_id") for e in unique))
                if key not in companion_groups:
                    companion_groups[key] = {
                        "keyword": word,
                        "entities": unique,
                    }

    for key, group in companion_groups.items():
        eids = set(e.get("entity_id") for e in group["entities"])
        # Check if any test case targets multiple entities from this group
        covered = False
        for c in enormous_cases:
            targets = set(c.get("metadata", {}).get("target_entities", []))
            if len(targets & eids) >= 2:
                covered = True
                break
        keyword = group["keyword"]
        if not covered:
            findings.append(("INFO",
                f"Companion group '{keyword}' ({len(eids)} entities) — "
                f"no cross-entity test case found.",
                "Consider adding a disambiguation test case for this group."))

    # Moved-but-not-renamed coverage
    findings.append(("INFO", "--- MOVED-BUT-NOT-RENAMED COVERAGE ---", ""))

    # Detect via entity_id area word analysis (simplified)
    area_id_to_name = {}
    areas_path = all_inventories.get("enormous", {})
    # Build area word sets
    all_area_words = {}
    for aid in enormous_inv.get("area_ids", set()):
        for word in aid.lower().split("_"):
            if len(word) > 2:
                all_area_words.setdefault(word, set()).add(aid)

    moved_candidates = []
    for e in enormous_inv["entities"]:
        area = e.get("area")
        if not area:
            continue
        eid = e.get("entity_id", "")
        if "." in eid:
            eid_parts = set(eid.split(".", 1)[1].lower().split("_"))
        else:
            eid_parts = set(eid.lower().split("_"))
        area_words = set(area.lower().split("_"))

        for word in eid_parts:
            if word in all_area_words:
                matching_areas = all_area_words[word]
                if area not in matching_areas and not (area_words & eid_parts):
                    moved_candidates.append(e)
                    break

    for e in moved_candidates:
        eid = e.get("entity_id", "")
        covered = any(eid in c.get("metadata", {}).get("target_entities", [])
                      for c in enormous_cases)
        if not covered:
            findings.append(("WARN",
                f"Moved-but-not-renamed candidate '{eid}' "
                f"(area: {e.get('area')}) has no test case.",
                "Moved-entity scenarios test name≠area mismatch reasoning. "
                "These are high-value disambiguation tests."))
        else:
            findings.append(("INFO",
                f"Moved-but-not-renamed candidate '{eid}' — covered.", ""))

    return findings


# ── Report ──

def format_phase_report(phase_name: str, findings: list) -> list:
    """Format a phase's findings into markdown."""
    lines = []
    lines.append(f"# Test Case Audit: {phase_name}")
    lines.append("")
    lines.append(f"**Generated:** {__import__('datetime').date.today()}")
    lines.append("")

    fail_count = sum(1 for s, _, _ in findings if s == "FAIL")
    warn_count = sum(1 for s, _, _ in findings if s == "WARN")
    info_count = sum(1 for s, _, _ in findings if s == "INFO")

    lines.append(f"**Summary:** {fail_count} FAIL, {warn_count} WARN, "
                 f"{info_count} INFO")
    lines.append("")

    if fail_count > 0:
        lines.append("❌ **Has FAIL findings — review required.**")
    elif warn_count > 0:
        lines.append("⚠️ **Has WARN findings — review recommended.**")
    else:
        lines.append("✅ **All checks passed.**")
    lines.append("")

    for severity, message, reasoning in findings:
        icon = {"FAIL": "❌", "WARN": "⚠️", "INFO": "ℹ️"}.get(severity, "")
        lines.append(f"**{severity}** {icon} {message}")
        if reasoning:
            lines.append(f"  → {reasoning}")
        lines.append("")

    return lines


# ── Main ──

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Audit test case NDJSON files.")
    parser.add_argument("test_cases_dir", type=Path,
                        help="Directory containing tier subdirs with NDJSON files")
    parser.add_argument("inventories_dir", type=Path,
                        help="Directory containing tier subdirs with YAML files")
    parser.add_argument("--output", type=Path, default=Path("."),
                        help="Output directory for reports")
    parser.add_argument("--phase", choices=["internal", "crossref", "coverage", "all"],
                        default="all", help="Which phase to run")
    parser.add_argument("--tiers", nargs="+", default=None,
                        help="Tiers to check (default: all found)")
    args = parser.parse_args()

    tc_base = args.test_cases_dir.resolve()
    inv_base = args.inventories_dir.resolve()
    output_dir = args.output.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    # Discover tiers
    if args.tiers:
        tiers = args.tiers
    else:
        tiers = [t for t in TIER_ORDER if (tc_base / t).is_dir()]

    if not tiers:
        print(f"ERROR: No tier directories found in {tc_base}")
        print(f"Expected subdirectories named: {', '.join(TIER_ORDER)}")
        print("If your test case files are elsewhere, provide the correct path.")
        sys.exit(1)

    print(f"Test cases: {tc_base}")
    print(f"Inventories: {inv_base}")
    print(f"Tiers: {', '.join(tiers)}")
    print(f"Phase: {args.phase}")
    print(f"Output: {output_dir}")
    print()

    # Load test cases
    all_cases = {}
    for tier_name in tiers:
        tier_dir = tc_base / tier_name
        if tier_dir.is_dir():
            cases = load_test_cases(tier_dir)
            all_cases[tier_name] = cases
            valid = sum(1 for c in cases if "_parse_error" not in c)
            errors = len(cases) - valid
            print(f"  {tier_name}: {valid} cases"
                  f"{f', {errors} parse errors' if errors else ''}")

    # Load inventories (needed for crossref and coverage)
    all_inventories = {}
    if args.phase in ("crossref", "coverage", "all"):
        for tier_name in tiers:
            inv_dir = inv_base / tier_name
            if inv_dir.is_dir():
                inv = load_inventory(inv_dir)
                all_inventories[tier_name] = inv
                print(f"  {tier_name} inventory: {len(inv['entity_ids'])} entities")
    print()

    total_fail = 0

    # Phase A: Internal
    if args.phase in ("internal", "all"):
        print("Phase A: Internal consistency...")
        findings = phase_internal(all_cases)
        report = format_phase_report("Phase A — Internal Consistency", findings)
        path = output_dir / "audit-test-cases-internal.md"
        with open(path, "w") as f:
            f.write("\n".join(report) + "\n")
        fail = sum(1 for s, _, _ in findings if s == "FAIL")
        total_fail += fail
        print(f"  → {path} ({fail} FAIL)")

    # Phase B: Cross-reference
    if args.phase in ("crossref", "all"):
        print("Phase B: Cross-reference with inventory...")
        findings = phase_crossref(all_cases, all_inventories)
        report = format_phase_report("Phase B — Cross-Reference", findings)
        path = output_dir / "audit-test-cases-crossref.md"
        with open(path, "w") as f:
            f.write("\n".join(report) + "\n")
        fail = sum(1 for s, _, _ in findings if s == "FAIL")
        total_fail += fail
        print(f"  → {path} ({fail} FAIL)")

    # Phase C: Coverage matrix
    if args.phase in ("coverage", "all"):
        print("Phase C: Coverage matrix...")
        findings = phase_coverage(all_cases, all_inventories)
        report = format_phase_report("Phase C — Coverage Matrix", findings)
        path = output_dir / "audit-test-cases-coverage.md"
        with open(path, "w") as f:
            f.write("\n".join(report) + "\n")
        fail = sum(1 for s, _, _ in findings if s == "FAIL")
        total_fail += fail
        print(f"  → {path} ({fail} FAIL)")

    print()
    print(f"Total FAIL findings: {total_fail}")
    sys.exit(1 if total_fail > 0 else 0)

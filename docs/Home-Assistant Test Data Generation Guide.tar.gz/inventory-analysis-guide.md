# Home Assistant Synthetic Inventory — Analysis Guide

**Purpose:** How to audit a single YAML inventory dataset for quality, completeness,
and adherence to the generation principles. Produces a findings report with
severity-tagged issues and reasoning.

**Audience:** An LLM agent or human evaluating an inventory dataset before declaring
it ready for test case generation or benchmarking.

**Created:** 2026-03-03

**See also:**
- `generation-guide.md` — index and overview
- `generation-principles.md` — what the inventory should contain and why
- `derivation-guide.md` — tier derivation rules (relevant for cross-tier checks)
- `audit_inventory.py` — utility script for static analysis (Steps 1-2)
- `test-case-analysis-guide.md` — companion guide for auditing NDJSON test cases

---

## Prerequisites

### Input data

The inventory dataset should be organized as:

```
<inventories_dir>/
  enormous/
    areas.yaml
    light.yaml
    sensor.yaml
    binary_sensor.yaml
    ... (one YAML per domain)
  large/
    ...
  medium/
    ...
  small/
    ...
```

The standard location is `test_data/inventories/` relative to the project data
directory. If the files aren't there, ask the user for the path to the directory
containing the tier subdirectories.

### Working directory

Create a working directory for output. The convention is:

```
scratch/tmp/audit-inventory/
```

Each step writes its findings to this directory as it completes, so context doesn't
need to be held across all steps simultaneously.

### User interaction

Some steps are run by utility scripts. The user (or the LLM via shell) runs the
script and reviews the output. Other steps require LLM reasoning and judgment.
The guide marks each step clearly:

- **🔧 Script step** — Run `audit_inventory.py` or similar. Well-defined, static
  analysis. No LLM reasoning needed.
- **🧠 LLM analysis step** — Requires reading data, applying principles, exercising
  judgment. The guide provides specific things to look for plus reasoning principles.

---

## Severity Definitions

Every finding gets a severity tag plus a reasoning line explaining *why*.

| Level | Meaning | Examples |
|-------|---------|---------|
| **FAIL** | Hard requirement violated. Blocks usage. | Duplicate entity_id, broken subset chain, missing unavailable actionable entity (enormous), entity references nonexistent area |
| **WARN** | Fuzzy target missed or quality concern. Worth investigating. | Light capability distribution outside guide range, area density skew, device_class breadth below threshold, no companion groups detected |
| **INFO** | Observation or potential issue. Be aware of. | Null-area entities present (expected), moved-but-not-renamed candidate detected, companion group identified |

The reasoning line is not optional. "FAIL: duplicate entity_id" is not useful.
"FAIL: `light.kitchen_ceiling` appears in both light.yaml and switch.yaml — entity
IDs must be unique across all domain files within a tier" is useful.

---

## Step 1: Static Analysis (🔧 Script)

**Run `audit_inventory.py`.**

```bash
python3 audit_inventory.py <inventories_dir> --output <working_dir>
```

This produces `audit-inventory.md` with findings across all tiers covering:

- Entity counts vs guide targets (per-domain for enormous, total for all tiers)
- Area counts vs guide targets
- Domain counts vs guide targets
- Duplicate entity_id detection
- Entity → area reference validation (entity's area exists in areas.yaml)
- Meta-state presence (unavailable, unknown) with actionable-domain check
- Null-area entity report
- Duplicate friendly name detection
- Light capability distribution vs guide §8 targets
- Device_class breadth for sensor and binary_sensor
- Area density analysis (skew detection)
- Moved-but-not-renamed candidate detection (word-overlap heuristic)
- Companion entity group detection (cross-domain keyword matching)
- Cross-tier: entity_id subset chain (small ⊂ medium ⊂ large ⊂ enormous)
- Cross-tier: entity identity preservation (shared entities have identical fields)

**Output:** `<working_dir>/audit-inventory.md`

**Action:** Read the report. Triage findings by severity. FAIL items are blockers —
investigate immediately. WARN items are worth understanding — some may be acceptable
deviations, others may need fixes. INFO items are context for later steps.

---

## Step 2: Review FAIL Items (🧠 LLM Analysis)

Read the FAIL findings from Step 1's report. For each:

1. **Understand the failure.** What specific data caused it?
2. **Locate the source.** Which YAML file, which tier, which entity?
3. **Assess impact.** Does this break downstream test case generation? Does it
   invalidate cross-tier analysis?
4. **Recommend a fix or document as accepted.** Some FAILs may be intentional
   deviations (document why). Most need fixes.

### What to look for specifically:

- **Duplicate entity_ids:** Usually copy-paste errors during generation. Check if
  the duplicates are in the same domain file (easy fix) or across domains (may
  indicate a real modeling question — e.g., should a device be in switch or light?).

- **Broken subset chain:** An entity in a smaller tier that doesn't exist in the
  larger tier. This means the derivation process added an entity instead of only
  subtracting. Check whether it's a typo (entity_id differs by one character) or
  a logical error (entity was independently generated for the smaller tier).

- **Entity identity mismatches:** A shared entity has different name/state/domain
  across tiers. This is almost always a derivation bug — the entity was modified
  during tier derivation instead of being copied verbatim.

- **Missing actionable unavailable entity (enormous):** The generation guide §9
  requires at least one unavailable entity in an actionable domain (light, switch,
  cover, etc.) for Step 8d test case generation. If missing, one must be added.

**Write findings to:** `<working_dir>/step2-fail-review.md`

---

## Step 3: Review WARN Items (🧠 LLM Analysis)

Read the WARN findings. For each, decide: acceptable deviation or needs investigation?

### Prescriptive checks (specific things to verify):

- **Light capability distribution misses:** Compare actual vs guide §8 targets. If
  the distribution is off, check whether the deviation is because the guide targets
  are miscalibrated (both ORIG and NEW datasets showed the same skew) or because
  this specific inventory has a genuine distribution problem. If both datasets
  consistently miss the same target, note it as a guide calibration issue rather
  than an inventory defect.

- **Area density warnings:** Some skew is expected and valuable — "tech hub" areas
  (office, garage) should have higher density. Flag it as a real problem only if
  a non-tech-hub area has extreme density, or if an area is so sparse it offers
  no testing value.

- **Device_class breadth below threshold:** Check whether the missing device_classes
  are exotic (nitrogen_dioxide, data_rate) or common ones that should be present
  (motion, door, temperature). Missing common classes is more concerning than
  missing exotic ones.

- **No duplicate friendly names:** If the script found zero duplicate name groups,
  the inventory lacks disambiguation test surface. The generation guide §5 expects
  multiple duplicate name groups across areas.

### Reasoning principles (how to think about WARNs):

- **Context matters more than numbers.** An inventory with 12 sensor device_classes
  instead of 15 is fine if the 12 cover all the semantically distinct categories
  (temperature, humidity, battery, power, motion-adjacent). An inventory with 15
  that are all temperature variants is worse.

- **Deviation from guide targets is not automatically wrong.** The guide targets
  were estimates based on the original generation, not empirically validated
  thresholds. If the deviation is consistent across multiple independent generations,
  the guide target may need recalibration rather than the inventory needing fixes.

- **Ask "does this affect test quality?"** A WARN about area density skew is only
  actionable if the skew would cause test cases to cluster in one area or leave
  other areas untestable. If the skew reflects realistic home layout (kitchen has
  more devices than a hallway), it's by design.

**Write findings to:** `<working_dir>/step3-warn-review.md`

---

## Step 4: Naming Quality (🧠 LLM Analysis)

Read through entity names across tiers, looking for naming diversity issues the
script can't catch.

### Prescriptive checks:

- **Moved-but-not-renamed candidates:** The script uses a word-overlap heuristic
  (flag when entity_id embeds an area word that doesn't match the assigned area,
  and the assigned area shares zero words with the entity_id area hint). This
  heuristic has limited sensitivity — it catches `old_living_room_lamp` in
  `guest_bedroom` but may miss subtler cases. Manually check whether the
  inventory has at least 1-2 moved-but-not-renamed entities. If not, note as
  a gap.

  **False positive awareness:** The heuristic can false-positive when area names
  are substrings of each other. "Master Bedroom Ceiling" in area `master_bedroom`
  should NOT flag because "bedroom" is shared. The word-overlap filter handles this,
  but verify the script's candidates are genuine.

- **Brand-name identifiers:** Look for entities where the friendly name contains
  a brand (Hue, Sonos, Ecobee, Ring, Nest, Lutron, etc.) that a user might
  reference by brand. The generation guide §7 expects "a handful" — not zero,
  not every entity.

- **Generic auto-generated names:** Look for entities with names like "Smart Plug 1",
  "Smart Bulb E7A2", etc. These test name-based disambiguation failure — the LLM
  must fall back to area or domain. At least 2-3 should exist in enormous.

- **Abbreviation inconsistency:** Look for cases where the same concept is spelled
  differently across entities (TV vs Television, Temp vs Temperature, BR vs Bedroom).
  At least 1-2 instances should exist.

### Reasoning principles:

- **Diversity should be sprinkled, not systematic.** A real HA install has mostly
  reasonable names with a minority of problematic ones. If 30% of entities have
  naming issues, the inventory is unrealistically messy. If 0% do, it's
  unrealistically clean.

- **The goal is exercising different reasoning paths.** Each naming issue category
  tests a different LLM capability: brand resolution, fallback reasoning, synonym
  handling, name-vs-area conflict resolution. One example of each is more valuable
  than five examples of the same category.

**Write findings to:** `<working_dir>/step4-naming-quality.md`

---

## Step 5: Realism Assessment (🧠 LLM Analysis)

Skim the inventory for realism issues that would make test results misleading.

### Prescriptive checks:

- **State distribution:** Are on/off states reasonably balanced? A home where every
  light is off and every lock is locked is unrealistically uniform. Check that
  there's a mix. The generation guide §2 says every non-transient state should be
  represented (enormous tier); smaller tiers accept gaps.

- **Companion entity group coherence:** For multi-entity devices (3D printer: switch +
  sensors; aquarium: light + sensor + switch), check that the component entities are
  in the same area and have compatible states. A 3D printer switch that's "off" but
  a printer nozzle temp sensor reading 215°C is incoherent.

- **Unusual domain mapping correctness:** Verify that unusual devices (standing desk
  as cover, wine cooler as climate, pet door as cover) have appropriate attributes.
  A standing desk cover entity should have position but NOT tilt. A wine cooler
  climate entity should have a narrow temperature range (not 60-85°F like HVAC).

- **Entity placement realism:** Quick scan for egregiously wrong placements — a
  lawn mower in a bedroom, a pool pump in the living room, etc. Mild
  unrealism (too many sensors in one room for state coverage) is acceptable and
  should be documented rather than fixed.

### Reasoning principles:

- **Test quality over realism when they conflict.** Having 3 vacuums is unrealistic
  but necessary for state coverage (docked, cleaning, error). Having a lawn mower
  in a bedroom is unrealistic AND doesn't serve any test purpose — that's a real bug.

- **Companion coherence matters for T3 scoring.** If a test case asks "is the 3D
  printer running?" and the model checks the power sensor, the sensor's state
  should be consistent with the switch's state. Incoherent companion states create
  unscorable test cases.

**Write findings to:** `<working_dir>/step5-realism.md`

---

## Step 6: Disambiguation Surface Assessment (🧠 LLM Analysis)

Evaluate whether the inventory provides adequate disambiguation challenges.

### Prescriptive checks:

- **Duplicate name group distribution:** Are duplicate friendly names distributed
  across enough different areas to create ambiguity? "Floor Lamp" appearing in 3
  areas is good. "Floor Lamp" appearing twice in the same area is a different
  (also valid but less common) test.

- **Same-domain same-area collisions:** Look for areas with multiple entities of the
  same domain where an unqualified command ("turn on the light in the kitchen")
  would be ambiguous. Kitchen with 8 lights is a classic example. Are there at
  least 2-3 such situations?

- **Cross-domain collisions:** Look for entities where a user command could route to
  multiple domains. "Turn off the TV" → media_player or switch. "Turn off the
  heater" → climate or switch. Are there at least 2-3 of these?

- **Null-area disambiguation:** Are there entities with `area: null` that can still
  be targeted by name? These test the LLM's ability to fall back from area-based
  to name-based targeting. The generation guide expects a few (portable heater,
  speaker groups, generic smart plugs).

### Reasoning principles:

- **Disambiguation surface should emerge from realistic layout, not be forced.**
  A kitchen with 8 lights is realistic and creates natural disambiguation. An
  artificial area with 15 entities of different types jammed together for
  "maximum disambiguation" is unrealistic and tests an unlikely scenario.

- **Consider the cascade:** Disambiguation isn't binary. "Turn on the light" in a
  house with 130 lights is a 3-level cascade: which area? → which light in that
  area? → which capability (just on, or on + brightness)? Check that the inventory
  supports at least some of these multi-level disambiguation chains.

- **Area name collisions are a distinct category.** "Hallway" vs "Upstairs Hallway"
  creates area-level ambiguity that's different from entity-level ambiguity. Check
  whether the inventory has any near-collision area names.

**Write findings to:** `<working_dir>/step6-disambiguation.md`

---

## Step 7: Consolidation

Merge findings from Steps 1-6 into a final report.

### Structure:

```markdown
# Inventory Audit — Final Report

## Summary
- X FAIL findings (list briefly)
- Y WARN findings (categorize)
- Z observations

## Blockers (FAIL)
[From Steps 1-2]

## Concerns (WARN)
[From Steps 1, 3]

## Naming Quality
[From Step 4]

## Realism
[From Step 5]

## Disambiguation Surface
[From Step 6]

## Guide Calibration Notes
[Any observations about guide targets that seem miscalibrated]

## Recommended Actions
[Prioritized list: what to fix, what to accept, what to investigate]
```

**Write to:** `<working_dir>/audit-inventory-final.md`

If desired, copy to a permanent location (e.g., `scratch/comparisons/`).

---

## Appendix: What This Guide Does NOT Cover

- **Comparison between two inventories.** Use the comparison scripts and methodology
  from the inventory comparison analysis for that.
- **Guide recalibration.** This guide surfaces where targets seem off; it doesn't
  change the generation guide itself.
- **Automated fixes.** This guide produces findings; humans or LLM agents apply fixes.
- **Test case quality.** That's `test-case-analysis-guide.md`.

# Validation Docs — Index

This directory contains guides and scripts for generating, deriving, validating, and
auditing the HA voice benchmark dataset (inventories + test cases).

---

## Guides

| File | Purpose |
|------|---------|
| `generation-guide.md` | Entry-point index for the inventory docs. Points to generation-principles, derivation-guide, and analysis guides. Start here if unsure which guide to use. |
| `generation-principles.md` | How to generate the Enormous inventory tier from scratch. YAML format, state rules, capability attributes, naming diversity, realism guidelines. |
| `derivation-guide.md` | How to derive smaller inventory tiers (Large, Medium, Small) from Enormous by top-down subtraction. Covers methodology, selection principles, and tooling. |
| `inventory-analysis-guide.md` | How to audit a single inventory YAML for quality, completeness, and adherence to generation principles. Produces a severity-tagged findings report. |
| `test-case-generation-principles.md` | How to generate structurally complete NDJSON test cases. Format spec, structural coverage derivation, utterance design, tool call construction. |
| `test-case-derivation-guide.md` | How to derive test cases from Enormous downward to Large/Medium/Small. Tier applicability rules, field adaptation, entity retargeting, push-down algorithm. |
| `test-case-expansion-guide.md` | How to expand a structurally complete test suite with additional variety, depth, and coverage of edge-case interaction patterns. **Draft/Untested.** |
| `test-case-analysis-guide.md` | How to audit a single NDJSON test case file. Three-phase: internal consistency, inventory cross-reference, coverage matrix. |
| `assembled-dataset-analysis-guide.md` | How to cross-reference an inventory tier and its test cases together for drift that is invisible when auditing each in isolation. Run after generating or significantly modifying a tier. |

## Scripts

| File | Purpose |
|------|---------|
| `audit_inventory.py` | Static analysis of a single inventory YAML. Run by inventory-analysis-guide.md. |
| `audit_test_cases.py` | Static analysis of a single test case NDJSON. Run by test-case-analysis-guide.md. |
| `verify_entity_consistency.py` | Entity consistency checks across a tier. Companion to audit_inventory.py. |
| `filter_inventory.py` | Inventory filtering utility used during derivation. |

---

## Recommended Execution Order

Run these guides in order when producing a new tier or updating existing data. Skip
phases that don't apply (e.g. skip derivation guides when working directly on
Enormous).

### Phase 1 — Generate

1. `generation-principles.md` — Generates `test_data/inventories/enormous/`
2. `test-case-generation-principles.md` — Generates `test_data/test_cases/enormous/`

### Phase 2 — Derive (per smaller tier: large, medium, small)

3. `derivation-guide.md` — Derives inventory tier from Enormous
4. `test-case-derivation-guide.md` — Derives test cases to match derived inventory
5. `test-case-expansion-guide.md` — Optional: add variety cases after structural pass *(Draft/Untested — not yet applied to any tier)*

### Phase 3 — Audit each file in isolation

6. `inventory-analysis-guide.md` — Audit per-domain inventory YAMLs
7. `test-case-analysis-guide.md` — Audit per-domain test case NDJSONs

### Phase 4 — Cross-reference audit (run once per tier after Phase 3)

8. `assembled-dataset-analysis-guide.md` — Cross-reference inventory vs. test cases for
   derivation drift, capability mismatches, and state assumption issues. Step 1 of this
   guide runs `scripts/assemble_tier.py --validate` for automated reference checks;
   Steps 2–7 are LLM-led analysis against the source files.

---

**Note on assembled files:** Phase 4 runs `assemble_tier.py --validate` only — no
files are written. When assembled files are needed for a benchmark run,
`scripts/assemble_tier.py` (without `--validate`) produces
`test_data/{tier}-ha-entities.yaml` and `test_data/{tier}-test-cases.ndjson` as
temporary artifacts. They are not committed. Fixes always go back into the per-domain
source files under `test_data/inventories/{tier}/` and `test_data/test_cases/{tier}/`.

# Home Assistant Test Cases — Analysis Guide

**Purpose:** How to audit a single NDJSON test case dataset for quality, completeness,
and correct alignment with its inventory. Three-phase structure: internal consistency,
inventory cross-reference, and coverage matrix. Produces findings reports with
severity-tagged issues and reasoning.

**Audience:** An LLM agent or human evaluating test case data before benchmarking.

**Created:** 2026-03-03

**See also:**
- `generation-guide.md` — index and overview
- `test-case-generation-principles.md` — what test cases should contain and why
- `test-case-derivation-guide.md` — tier derivation rules
- `audit_test_cases.py` — utility script for static analysis
- `audit_inventory.py` — utility script for inventory analysis (used in Phase B)
- `inventory-analysis-guide.md` — companion guide for auditing YAML inventories

---

## Prerequisites

### Input data

The test case dataset and its paired inventory should be organized as:

```
<test_cases_dir>/
  enormous/
    light_test_cases.ndjson
    sensor_test_cases.ndjson
    cross_domain_test_cases.ndjson
    utility_test_cases.ndjson
    ...
  large/
    ...
  medium/
    ...
  small/
    ...

<inventories_dir>/
  enormous/
    areas.yaml
    light.yaml
    sensor.yaml
    ...
  large/
    ...
  medium/
    ...
  small/
    ...
```

The standard location is `test_data/test_cases/` and `test_data/inventories/`
relative to the project data directory. If the files aren't at these paths, ask
the user where the two directories are.

### Working directory

```
scratch/tmp/audit-test-cases/
```

### Step types

- **🔧 Script step** — Run `audit_test_cases.py`. Static analysis, no LLM needed.
- **🧠 LLM analysis step** — Requires reading data, applying principles, judgment.

---

## Severity Definitions

| Level | Meaning | Examples |
|-------|---------|---------|
| **FAIL** | Hard requirement. Blocks usage. | Entity name in tool_call doesn't exist in inventory, JSON parse error, duplicate case_key within tier, case_key subset chain broken |
| **WARN** | Quality concern. Worth investigating. | Tool not tested in actionable domain, duplicate name group has no disambiguation test, no cases for domain with entities in inventory, action_done with empty tool_calls |
| **INFO** | Observation. Be aware. | Retarget count, case count per file, distribution summaries |

Every finding includes reasoning explaining *why* it matters and what to do about it.

---

## Phase A: Test Cases Internally

Verify the test case files are well-formed and internally consistent, without
reference to the inventory.

### Step 1: Internal Static Analysis (🔧 Script)

```bash
python3 audit_test_cases.py <test_cases_dir> <inventories_dir> \
    --phase internal --output <working_dir>
```

This produces `audit-test-cases-internal.md` covering:

- JSON parse validation (every line in every NDJSON file must be valid JSON)
- Required field presence (id, utterance, expected_tool_calls, expected_response_type,
  inventory_tier, metadata)
- Required metadata field presence (complexity, target_entities, case_key)
- Response type values are from the valid set (action_done, query_response,
  text_response, error, clarification)
- Complexity values are from the valid set (simple, moderate, complex, ambiguous,
  edge_case)
- case_key uniqueness within each tier
- inventory_file path consistency within each tier
- Per-file case counts
- Response type and complexity distributions
- Consistency checks: action_done cases have tool_calls, error/text cases don't

**Output:** `<working_dir>/audit-test-cases-internal.md`

**Action:** Review FAIL items first. Parse errors and missing required fields are
blockers. WARN items about response_type / tool_call consistency may indicate
classification errors.

### Step 2: Utterance Quality (🧠 LLM Analysis)

Sample 20-30 cases across tiers and domain files. Read the utterances.

#### Prescriptive checks:

- **Voice-assistant style:** Utterances should be direct commands or questions as
  spoken to a voice assistant. No politeness markers ("please turn on"), no filler
  ("hey Claude, can you"), no written-text conventions (complete sentences with
  periods). Occasional natural phrasing ("the kitchen is too hot") is fine and
  valuable.

- **Domain file placement:** Entity-specific test cases should be in their domain
  file (light cases in `light_test_cases.ndjson`). Disambiguation cases involving
  multiple domains should be in `cross_domain_test_cases.ndjson`. Inventory-
  independent cases (time, date, broadcast, out-of-scope, conversational) should
  be in `utility_test_cases.ndjson`.

- **Utterance diversity within a domain:** Do utterances vary in phrasing, or are
  they all "turn on the X" / "turn off the X"? Good test sets include state
  queries ("is the X on"), area commands ("turn off the bedroom lights"), and
  domain-specific verbs ("dim", "lock", "skip", "pause").

- **Seed vs disambiguation distinction:** Simple, unambiguous cases testing one
  tool × one entity belong in domain files (these are "seed" cases). Cases
  designed to test disambiguation between entities or domains belong in
  cross_domain. If domain files contain complex disambiguation logic, that's
  a placement issue.

#### Reasoning principles:

- **Utterances are the primary benchmark input.** If utterances are unrealistic or
  overly easy (always include the exact entity name), the benchmark will overstate
  model accuracy. Good utterances use natural references ("the TV", "the hallway
  light") that require the model to resolve against the inventory.

- **Harder utterances belong in cross_domain, not in domain files.** Domain files
  should primarily exercise tool coverage (does the model pick the right tool for
  this domain?). Cross_domain tests routing (does the model pick the right domain?).

**Write findings to:** `<working_dir>/step2-utterance-quality.md`

### Step 3: Metadata Quality (🧠 LLM Analysis)

Sample 15-20 cases, focusing on cases rated `ambiguous` or `complex`.

#### Prescriptive checks:

- **Complexity ratings consistency:** Are `simple` cases truly simple (one entity,
  one tool, clear name match)? Are `ambiguous` cases genuinely ambiguous (multiple
  valid interpretations)? A case rated `simple` that involves 3 entities in the same
  area is misrated. A case rated `ambiguous` where there's clearly only one valid
  target is misrated.

- **Notes field evaluation-readiness:** Do notes contain T3 analysis hooks?
  Phrases like "does the model communicate...", "T3 analysis:", "quality of
  explanation" indicate the case is designed for multi-tier scoring. Cases
  without notes (especially complex/ambiguous ones) are harder to score
  consistently.

- **response_type boundary correctness:** Check the boundary between `clarification`
  and `action_done` for ambiguous cases. If the case has `expected_tool_calls: []`
  and `response_type: clarification`, are there reasonable alternatives that also
  list tool calls? If `response_type: action_done` but the case is genuinely
  ambiguous, should it be `clarification` instead?

- **Alternative quality ratings:** Alternatives should have `quality` values
  (equivalent, acceptable, degraded) with `reason` strings explaining the
  quality distinction. Missing quality ratings make alternatives unusable
  for scoring.

#### Reasoning principles:

- **Complexity should reflect what the model must reason about, not what the
  answer is.** "Turn on the coffee maker" is simple because the model just matches
  a name. "Turn off the heater" is ambiguous because there are 5 heater entities
  across domains with no area context, even though the expected response is just
  "ask for clarification."

- **The notes field is an investment in scorer quality.** Without notes explaining
  what to look for in the model's response, human evaluators (or automated scorers)
  must re-derive the evaluation criteria for every case. This is expensive and
  inconsistent.

**Write findings to:** `<working_dir>/step3-metadata-quality.md`

---

## Phase B: Inventories Internally

Verify the inventory YAML data is internally sound. This is the same analysis as
the `inventory-analysis-guide.md`, included here because test case quality depends
on inventory quality.

### Step 4: Inventory Static Analysis (🔧 Script)

If you've already run the inventory audit (following `inventory-analysis-guide.md`),
you can reference that output. Otherwise:

```bash
python3 audit_inventory.py <inventories_dir> --output <working_dir>
```

**Output:** `<working_dir>/audit-inventory.md`

**Action:** Review the output. FAIL items in the inventory directly affect test case
validity — a broken inventory means broken test cases. If the inventory has
significant issues, fix those before continuing with Phase C.

---

## Phase C: Cross-Reference Test Cases ↔ Inventories

This is the highest-value phase. It verifies that test cases correctly reference
inventory data and that the inventory's test-relevant features are exercised.

### Step 5: Entity Reference Cross-Check (🔧 Script)

```bash
python3 audit_test_cases.py <test_cases_dir> <inventories_dir> \
    --phase crossref --output <working_dir>
```

This produces `audit-test-cases-crossref.md` covering:

- **target_entities validation:** Every entity_id in `metadata.target_entities`
  exists in the tier's inventory.
- **Tool call name validation:** Every `name` and `name_any_of` value in
  `expected_tool_calls` (and alternatives) matches a friendly name in the inventory.
- **Tool call area validation:** Every `area` value in `expected_tool_calls` matches
  an area name in the inventory.
- **case_key subset chain:** small keys ⊂ medium ⊂ large ⊂ enormous.
- **Case count monotonic decrease:** enormous ≥ large ≥ medium ≥ small.
- **Retarget detection:** Cases where the same case_key has different utterances
  across tiers.
- **Empty file validation:** Domain files with 0 cases where the domain has entities
  in the inventory.

**Output:** `<working_dir>/audit-test-cases-crossref.md`

**Action:** Entity reference FAILs are the most common and most critical issue.
These are usually entity name confabulations — the test case was written with
an entity name constructed from the entity_id rather than copied from the
inventory's `name:` field. This is the exact LLM failure mode documented in
the generation guide §7 (entity_id safety).

case_key subset violations indicate derivation bugs. A case dropped from a
larger tier should not reappear in a smaller tier via retargeting. The fix is
usually to either add the retargeted case back to the intermediate tier or
remove it from the smaller tier.

### Step 6: Coverage Matrix (🔧 Script)

```bash
python3 audit_test_cases.py <test_cases_dir> <inventories_dir> \
    --phase coverage --output <working_dir>
```

This produces `audit-test-cases-coverage.md` covering:

- **Tool × domain matrix:** Which tools are tested in which domain files.
- **Generic tool gaps:** HassTurnOn/Off, HassToggle, HassGetState not tested
  in actionable domains.
- **Duplicate name group coverage:** For each set of entities sharing a friendly
  name, is there a disambiguation test case?
- **Unavailable entity coverage:** Are actionable unavailable entities targeted
  by edge case test cases?
- **Unusual state coverage:** Entities in jammed, error, or unknown states —
  do test cases exercise them?
- **Companion group coverage:** Multi-domain device groups — do test cases
  exercise cross-entity disambiguation?
- **Moved-but-not-renamed coverage:** Name≠area mismatch entities — do test
  cases target them?

**Output:** `<working_dir>/audit-test-cases-coverage.md`

**Action:** WARNs here are coverage gaps, not errors. Prioritize:
1. Duplicate name groups without tests (these are the core disambiguation surface)
2. Actionable unavailable entities without tests (required by guide §9)
3. Moved-but-not-renamed entities without tests (high-value edge cases)
4. Tool × domain gaps (some are expected — not every tool applies to every domain)

### Step 7: Coverage Gap Assessment (🧠 LLM Analysis)

Review the coverage matrix output from Step 6. For each WARN:

#### Prescriptive checks:

- **Is the gap real?** Some script-detected gaps are false positives. A tool ×
  domain gap for HassToggle × vacuum is expected (vacuums don't toggle). A gap
  for HassTurnOff × fan is a real problem (fans should have on/off tests).

- **Is the gap covered elsewhere?** A tool might not appear in a domain file but
  IS tested in `cross_domain_test_cases.ndjson`. Check before flagging as missing.

- **Does the gap matter for benchmarking?** A missing test case for a rare
  tool × domain combination (HassLawnMowerDock in the small tier where lawn_mower
  entities don't exist) is not a problem. A missing test case for HassTurnOn ×
  media_player is a significant gap.

#### Reasoning principles:

- **Coverage completeness is a spectrum, not a binary.** The goal is not 100%
  coverage of every theoretical combination, but coverage of every combination
  a real user would encounter. Prioritize high-frequency interactions (lights,
  locks, climate, media) over edge cases (lawn mower, todo).

- **Each inventory feature exists for a reason.** If the inventory has 4 nightlights
  with the same name across 4 areas, there should be a test case that says "turn
  on the nightlight" to test disambiguation. If such a case is missing, either
  the test data has a gap or the inventory feature is wasted.

- **The coverage matrix is a conversation starter, not a verdict.** It shows what
  IS and ISN'T covered. The LLM analysis adds judgment about what SHOULD be covered.

#### Expected argument over-constraint checks:

These checks identify cases where expected tool call arguments are stricter
than necessary, penalizing models that make correct but less-precise calls.

- **Domain in name-targeted calls:** For generic tools (HassTurnOn/Off,
  HassToggle, HassGetState) where the expected args include both `name` and
  `domain`: check whether the entity name is unique across all domains in the
  inventory. If it maps to only one domain, `domain` is not required for
  disambiguation — add a domain-free version as an `acceptable` alternative.
  Cases using `area` + `domain` (no `name`) are fine — domain narrows which
  entities in the area are targeted.

  Detection: `fix_domain_and_volume.py` in the test cases directory can detect
  and fix these automatically.

- **HassSetVolumeRelative numeric vs string:** The HA schema permits
  `volume_step` as either an integer or a string (`"up"`/`"down"`). When the
  utterance specifies a magnitude and the expected value is numeric, ensure
  the directional string form is included as an `acceptable` alternative.

**Write findings to:** `<working_dir>/step7-coverage-gaps.md`

### Step 8: Retarget Quality Review (🧠 LLM Analysis)

Read the retarget detection output from Step 5's report. Sample 10-15 retargeted
cases across tiers.

#### Prescriptive checks:

- **Does the retarget preserve the test's purpose?** A test case for "pause the
  kitchen display" retargeted to "pause the bathroom speaker" preserves the
  HassMediaPause tool test. A test for "close the back yard drip irrigation"
  retargeted to "close the gas main" changes the real-world safety implications
  even though HassTurnOff × valve is preserved. Note significant character changes.

- **Device type drift:** When the retargeted entity is a fundamentally different
  device type (garage door → bedroom shade, ceiling fan → range hood), the test
  case may behave differently in T3 evaluation even though T1/T2 scoring is
  unaffected. Flag cases where the device type change is dramatic.

- **Disambiguation cases correctly dropped:** When a disambiguation scenario requires
  entities that don't exist in a smaller tier (e.g., 3 desk lamps → 1 desk lamp),
  the case should be dropped, not retargeted to a non-ambiguous version. Check that
  disambiguation cases are dropped (not retargeted) when the ambiguity no longer
  exists.

- **Utility cases unchanged:** Cases with `inventory_tier: "all"` should have
  identical utterances and tool calls across all tiers. If they differ, something
  went wrong in derivation.

#### Reasoning principles:

- **Retargeting should be invisible to the benchmark.** A well-retargeted case tests
  the same LLM capability as the original, just with different entity names. If
  reading the retargeted case reveals that it's testing something qualitatively
  different, the retarget is problematic.

- **It's better to drop than to force-fit.** If the available entities in a smaller
  tier can't support the original test's intent, dropping the case is better than
  retargeting it to something that superficially matches but tests a different skill.

**Write findings to:** `<working_dir>/step8-retarget-quality.md`

### Step 9: Edge Case Completeness (🧠 LLM Analysis)

Review the test data for presence of standard edge case categories.

#### Checklist (each should have at least one test case in enormous):

| Category | Description | Example |
|----------|-------------|---------|
| Nonexistent entity | User names something not in inventory | "turn on the basement lights" |
| Unsupported action | Valid entity, wrong action type | "dim the front door lock" |
| Wrong domain action | Action exists but not for this domain | "set the lock to 50%" |
| Unavailable actionable | Action on an offline device | "turn on the smart bulb" (unavailable) |
| Jammed/error state query | Query an entity in error state | "is the mailbox locked" (jammed) |
| Jammed/error state action | Action on entity in error state | "unlock the mailbox" (jammed) |
| Gibberish/STT noise | Uninterpretable input | "asdf qwerty zxcv" |
| Incomplete command | Truncated or missing key info | "turn on the", "set temperature to" |
| Out-of-scope request | Beyond HA capabilities | "order paper towels", "set an alarm" |
| Conversational | Greeting, meta-question, thanks | "hello", "what can you do" |
| General knowledge | Factual question unrelated to HA | "capital of France" |
| Implicit intent | Indirect command requiring inference | "goodnight", "I'm heading out" |
| Tool limitation | Query that exceeds tool capability | "forecast for tomorrow" (tool returns current only) |

#### Reasoning principles:

- **"Plausible but missing" is harder than "clearly absent."** "Turn on the
  swimming pool lights" in a home with a pool pump but no pool lights tests
  whether the model invents plausible entities. "Turn on the basement lights"
  in a home with no basement is easier because nothing in the inventory hints
  at a basement. Both are valid; the plausible-but-missing variant is the
  stronger test.

- **Edge cases are where models reveal character.** Simple on/off commands
  differentiate bad models from adequate ones. Edge cases differentiate adequate
  from good. Check that edge cases have notes explaining what "good" looks like
  for T3 scoring.

- **Implicit intent is the hardest category.** "Goodnight" has no single correct
  answer. The quality of alternatives and the breadth of acceptable interpretations
  are more important here than having one "right" expected_tool_calls.

**Write findings to:** `<working_dir>/step9-edge-cases.md`

---

## Step 10: Consolidation

Merge findings from all phases into a final report.

### Structure:

```markdown
# Test Case Audit — Final Report

## Summary
- Phase A: X FAIL, Y WARN (internal consistency)
- Phase B: X FAIL, Y WARN (inventory quality)
- Phase C: X FAIL, Y WARN (cross-reference + coverage)

## Blockers (FAIL)
[Entity ref errors, parse errors, subset chain violations]

## Coverage Gaps
[From Steps 6-7: what's missing and how much it matters]

## Retarget Issues
[From Step 8: problematic retargets]

## Edge Case Assessment
[From Step 9: checklist results]

## Utterance & Metadata Quality
[From Steps 2-3]

## Recommended Actions
[Prioritized: fix, accept, investigate]
```

**Write to:** `<working_dir>/audit-test-cases-final.md`

---

## Appendix: What This Guide Does NOT Cover

- **Comparison between two test case datasets.** Use the comparison methodology
  (ha_test_case_comparison.md) for that.
- **Test case generation or derivation.** Use `test-case-generation-principles.md`
  and `test-case-derivation-guide.md` for creating test cases.
- **Benchmark execution.** This guide verifies data quality pre-benchmark.
- **Inventory generation.** Use `generation-principles.md` for creating inventories.
- **Automated fixes.** This guide surfaces issues; humans or LLM agents fix them.

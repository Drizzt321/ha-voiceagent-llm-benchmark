# Home Assistant Synthetic Inventory — Guide Index

**Purpose:** Entry point for the HA synthetic inventory documentation. Points to the
right file for the task at hand.

**Created:** 2026-03-01 (Step 10, M2)

---

## What these are

Synthetic HA home inventories at four scales (Enormous → Large → Medium → Small) for
benchmarking LLM voice assistant performance. The Enormous tier is generated from
scratch following design principles; smaller tiers are mechanically derived from it
by subtraction.

## Documents

| File | Lines | Use when... |
|------|-------|-------------|
| **generation-principles.md** | ~800 | Generating or regenerating the Enormous tier from scratch. YAML format, state rules, capability attributes, disambiguation scenarios, realism guidelines, naming diversity, and the Enormous design record. |
| **derivation-guide.md** | ~250 | Deriving Large/Medium/Small tiers from Enormous. Methodology, selection principles, tooling, edge case degradation tracking, and per-tier design records. |
| **filter_inventory.py** | ~100 | Mechanical extraction tool for tier derivation. Takes a keep-list + source tier → filtered output. |
| **test-case-generation-principles.md** | ~700 | Generating NDJSON test cases against a YAML inventory. Format spec, coverage goals, reasoning methodology, utterance design, tool call construction, entity_id safety, worked examples. |
| **test-case-derivation-guide.md** | ~400 | Deriving test cases from Enormous to smaller tiers. Tier applicability rules, retargeting, partial match handling, push-down algorithm, worked examples. |
| **verify_entity_consistency.py** | ~300 | Post-generation verification. Checks YAML cross-tier subset integrity and NDJSON `target_entities` against YAML entity_ids. Run after any data generation or modification. |
| **inventory-analysis-guide.md** | ~350 | Auditing a single YAML inventory dataset for quality, completeness, and adherence to generation principles. Step-by-step with script + LLM analysis phases. |
| **test-case-analysis-guide.md** | ~400 | Auditing a single NDJSON test case dataset. Three-phase: internal consistency, inventory cross-reference, coverage matrix. |
| **audit_inventory.py** | ~500 | Static analysis of inventory YAML. Entity counts, subset chain, meta-states, naming, disambiguation surface, light capability distribution. Produces severity-tagged markdown report. |
| **audit_test_cases.py** | ~550 | Static analysis of test case NDJSON. Entity ref verification, case_key subset chain, tool × domain coverage matrix, retarget detection. Produces severity-tagged markdown reports. |

## Related reference docs

These live in the project's `reference/` directory and provide domain-specific detail
that the generation and derivation guides reference:

- `ha-domain-behavior-reference.md` — what each HA tool returns per entity type
- `ha-domain-tool-coverage-matrix.md` — domain × tool coverage, disambiguation scenarios
- `ha-test-generation-reasoning-guide.md` — quality judgment framework for test cases
- `ha-voice-llm-research.md` — HA ↔ LLM interface research (prompt format, entity context)
- `benchmarking-framework-research/research-ha-intent-tools.md` — full 37-tool inventory

External: Porter's `home-assistant-synthetic-home` schema —
https://github.com/allenporter/home-assistant-synthetic-home

## Inventory directory structure

```
ha-voice-bench-m2/
├── generation-guide.md          ← this file
├── generation-principles.md     ← how to generate Enormous
├── derivation-guide.md          ← how to derive smaller tiers
├── filter_inventory.py          ← derivation extraction tool
├── test-case-generation-principles.md ← how to generate NDJSON test cases
├── test-case-derivation-guide.md    ← how to derive test cases to smaller tiers
├── verify_entity_consistency.py     ← post-generation data verification
├── inventory-analysis-guide.md      ← how to audit inventory quality
├── test-case-analysis-guide.md      ← how to audit test case quality
├── audit_inventory.py               ← inventory audit utility script
├── audit_test_cases.py              ← test case audit utility script
├── enormous/                    ← 453 entities, 20 areas, 14 domains
│   ├── areas.yaml
│   └── {domain}.yaml × 14
├── large/                       ← 185 entities, 14 areas, 14 domains
│   ├── areas.yaml
│   └── {domain}.yaml × 14
├── medium/                      ← 88 entities, 8 areas, 13 domains
│   ├── areas.yaml
│   └── {domain}.yaml × 13
├── small/                       ← 34 entities, 5 areas, 11 domains
│   ├── areas.yaml
│   └── {domain}.yaml × 11
└── merge-script-spec.md         ← spec for combining per-domain → combined.yaml
```

## Per-tier file structure

Each tier directory contains per-domain YAML files plus test cases (Step 12):

```
{tier}/
├── areas.yaml                    ← area definitions (canonical)
├── {domain}.yaml                 ← entities for one domain
├── {domain}_test_cases.ndjson    ← companion test cases (Step 12, future)
├── cross_domain_test_cases.ndjson ← multi-domain test cases (Step 12, future)
├── combined.yaml                  ← GENERATED by merge script (future)
└── combined_test_cases.ndjson     ← GENERATED by merge script (future)
```

## Workflow

**To generate Enormous from scratch:**
Read `generation-principles.md` end-to-end. It contains everything needed: format
conventions, state rules, attribute guidance, disambiguation scenarios, realism
guidelines, and the Enormous design record as a worked example.

**To derive smaller tiers from Enormous:**
Read `derivation-guide.md`. It covers the methodology, selection principles, tooling
(`filter_inventory.py`), and includes design records for Large/Medium/Small as
worked examples. Cross-references `generation-principles.md` for edge case definitions.

**To generate test cases:**
Read `test-case-generation-principles.md` end-to-end. It covers the NDJSON format spec,
coverage goals, reasoning methodology, utterance design, tool call construction, and
entity_id safety rules. Reference `ha-test-generation-reasoning-guide.md` in `reference/`
for the quality judgment framework.

**To derive test cases for smaller tiers:**
Read `test-case-derivation-guide.md`. It covers tier applicability rules, retargeting
strategies, the push-down algorithm, and worked examples.

After generating or deriving test cases, run `verify_entity_consistency.py` to confirm all
`target_entities` values match the YAML inventories. See `derivation-guide.md` §10
for details and the root cause of the lock `_lock` suffix bug.

**To audit an inventory dataset:**
Read `inventory-analysis-guide.md`. Run `audit_inventory.py` for static analysis, then
follow the LLM analysis steps for naming quality, realism, and disambiguation surface.

**To audit a test case dataset:**
Read `test-case-analysis-guide.md`. Run `audit_test_cases.py` for static analysis
(internal consistency, cross-reference, coverage matrix), then follow the LLM analysis
steps for utterance quality, retarget review, and edge case completeness.

## Maintenance

Update these documents when:
- HA adds new domains or intent tools that need inventory coverage
- New disambiguation scenarios are identified
- Attribute schemas change in a new HA version
- Benchmarking experience reveals gaps in the generation methodology
- A new inventory tier is generated and design decisions should be recorded
